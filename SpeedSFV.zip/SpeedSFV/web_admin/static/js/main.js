// SpeedSFV Admin Panel JavaScript

document.addEventListener('DOMContentLoaded', function() {
    // Flash message auto-dismiss
    const flashMessages = document.querySelectorAll('.flash-message');
    flashMessages.forEach(message => {
        setTimeout(() => {
            message.style.opacity = '0';
            setTimeout(() => {
                message.style.display = 'none';
            }, 500);
        }, 5000);
    });
    
    // Mobile sidebar toggle
    const sidebarToggle = document.createElement('button');
    sidebarToggle.className = 'sidebar-toggle';
    sidebarToggle.innerHTML = '<i class="fas fa-bars"></i>';
    sidebarToggle.style.position = 'fixed';
    sidebarToggle.style.top = '16px';
    sidebarToggle.style.left = '16px';
    sidebarToggle.style.zIndex = '100';
    sidebarToggle.style.display = 'none';
    sidebarToggle.style.backgroundColor = 'var(--primary-color)';
    sidebarToggle.style.color = 'white';
    sidebarToggle.style.border = 'none';
    sidebarToggle.style.borderRadius = '50%';
    sidebarToggle.style.width = '40px';
    sidebarToggle.style.height = '40px';
    sidebarToggle.style.cursor = 'pointer';
    
    document.body.appendChild(sidebarToggle);
    
    sidebarToggle.addEventListener('click', function() {
        const sidebar = document.querySelector('.sidebar');
        sidebar.classList.toggle('mobile-open');
    });
    
    // Responsive sidebar
    function checkWindowSize() {
        const sidebar = document.querySelector('.sidebar');
        if (sidebar) {
            if (window.innerWidth < 768) {
                sidebarToggle.style.display = 'block';
                sidebar.style.transform = 'translateX(-100%)';
                sidebar.style.transition = 'transform 0.3s ease';
                
                // Add mobile-open class styling
                const style = document.createElement('style');
                style.innerHTML = `
                    .sidebar.mobile-open {
                        transform: translateX(0) !important;
                    }
                `;
                document.head.appendChild(style);
            } else {
                sidebarToggle.style.display = 'none';
                sidebar.style.transform = 'translateX(0)';
            }
        }
    }
    
    window.addEventListener('resize', checkWindowSize);
    checkWindowSize();
    
    // Theme toggle functionality
    const themeToggle = document.createElement('button');
    themeToggle.className = 'theme-toggle';
    themeToggle.innerHTML = '<i class="fas fa-moon"></i>';
    themeToggle.style.position = 'fixed';
    themeToggle.style.bottom = '16px';
    themeToggle.style.right = '16px';
    themeToggle.style.zIndex = '100';
    themeToggle.style.backgroundColor = 'var(--card-background)';
    themeToggle.style.color = 'var(--text-color)';
    themeToggle.style.border = '1px solid rgba(0, 0, 0, 0.1)';
    themeToggle.style.borderRadius = '50%';
    themeToggle.style.width = '40px';
    themeToggle.style.height = '40px';
    themeToggle.style.cursor = 'pointer';
    themeToggle.style.boxShadow = 'var(--box-shadow)';
    
    document.body.appendChild(themeToggle);
    
    // Check for saved theme preference or use device preference
    const savedTheme = localStorage.getItem('theme');
    if (savedTheme === 'dark') {
        document.documentElement.classList.add('dark-theme');
        themeToggle.innerHTML = '<i class="fas fa-sun"></i>';
    } else if (savedTheme === 'light') {
        document.documentElement.classList.add('light-theme');
    } else if (window.matchMedia && window.matchMedia('(prefers-color-scheme: dark)').matches) {
        document.documentElement.classList.add('dark-theme');
        themeToggle.innerHTML = '<i class="fas fa-sun"></i>';
    }
    
    themeToggle.addEventListener('click', function() {
        if (document.documentElement.classList.contains('dark-theme')) {
            document.documentElement.classList.remove('dark-theme');
            document.documentElement.classList.add('light-theme');
            localStorage.setItem('theme', 'light');
            themeToggle.innerHTML = '<i class="fas fa-moon"></i>';
        } else {
            document.documentElement.classList.remove('light-theme');
            document.documentElement.classList.add('dark-theme');
            localStorage.setItem('theme', 'dark');
            themeToggle.innerHTML = '<i class="fas fa-sun"></i>';
        }
    });
    
    // Add dark theme styles
    const darkThemeStyle = document.createElement('style');
    darkThemeStyle.innerHTML = `
        .dark-theme {
            --background-color: #1d1d1f;
            --card-background: #2c2c2e;
            --text-color: #f5f5f7;
            --secondary-color: #86868b;
        }
        
        .light-theme {
            --background-color: #f5f5f7;
            --card-background: #ffffff;
            --text-color: #1d1d1f;
            --secondary-color: #86868b;
        }
    `;
    document.head.appendChild(darkThemeStyle);
});
