import os
import json
import datetime
import secrets
from flask import Flask, render_template, request, redirect, url_for, jsonify, flash, session
from flask_socketio import SocketIO
from flask_login import LoginManager, UserMixin, login_user, login_required, logout_user, current_user
from werkzeug.security import generate_password_hash, check_password_hash
from werkzeug.utils import secure_filename
import sys
import threading
import glob
from pyngrok import ngrok

# Add parent directory to path to import SpeedSFV modules
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from ai_detector import AIDetector
from scanner import Scanner
from updater import Updater

app = Flask(__name__)
app.config['SECRET_KEY'] = secrets.token_hex(16)
app.config['UPLOAD_FOLDER'] = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), 'quarantine', 'uploads')
app.config['MAX_CONTENT_LENGTH'] = 50 * 1024 * 1024  # 50MB max upload size
socketio = SocketIO(app)

# Ensure upload directory exists
os.makedirs(app.config['UPLOAD_FOLDER'], exist_ok=True)

# Initialize login manager
login_manager = LoginManager()
login_manager.init_app(app)
login_manager.login_view = 'login'

# Admin user class
class User(UserMixin):
    def __init__(self, id, username, password_hash):
        self.id = id
        self.username = username
        self.password_hash = password_hash

# Admin users (in a real app, this would be in a database)
users = {
    '1': User('1', 'admin', generate_password_hash('admin123'))
}

@login_manager.user_loader
def load_user(user_id):
    return users.get(user_id)

# Path to quarantine database
QUARANTINE_DB_PATH = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), 'quarantine', 'quarantine_db.json')

# Initialize AI detector and scanner
ai_detector = AIDetector()
scanner = Scanner()
updater = Updater(update_url="https://api.github.com/repos/yourusername/speedsfv/releases/latest")

# System statistics
system_stats = {
    'scans_performed': 0,
    'threats_detected': 0,
    'files_quarantined': 0,
    'last_scan': None
}

# Load quarantine database
def load_quarantine_db():
    if os.path.exists(QUARANTINE_DB_PATH):
        with open(QUARANTINE_DB_PATH, 'r') as f:
            return json.load(f)
    return {"quarantined_files": []}

# Save quarantine database
def save_quarantine_db(db):
    with open(QUARANTINE_DB_PATH, 'w') as f:
        json.dump(db, f, indent=4)

# Routes
@app.route('/')
def index():
    if current_user.is_authenticated:
        return redirect(url_for('dashboard'))
    return redirect(url_for('login'))

@app.route('/login', methods=['GET', 'POST'])
def login():
    if current_user.is_authenticated:
        return redirect(url_for('dashboard'))
    
    if request.method == 'POST':
        username = request.form.get('username')
        password = request.form.get('password')
        
        for user_id, user in users.items():
            if user.username == username and check_password_hash(user.password_hash, password):
                login_user(user)
                return redirect(url_for('dashboard'))
        
        flash('Invalid username or password')
    
    return render_template('login.html', theme='dark')

@app.route('/logout')
@login_required
def logout():
    logout_user()
    return redirect(url_for('login'))

@app.route('/dashboard')
@login_required
def dashboard():
    quarantine_db = load_quarantine_db()
    return render_template('dashboard.html', 
                          quarantine_count=len(quarantine_db["quarantined_files"]),
                          system_stats=system_stats, theme='dark')

@app.route('/quarantine')
@login_required
def quarantine():
    quarantine_db = load_quarantine_db()
    return render_template('quarantine.html', quarantined_files=quarantine_db["quarantined_files"], theme='dark')

@app.route('/quarantine/delete/<int:file_id>', methods=['POST'])
@login_required
def delete_quarantined_file(file_id):
    quarantine_db = load_quarantine_db()
    
    if file_id < len(quarantine_db["quarantined_files"]):
        del quarantine_db["quarantined_files"][file_id]
        save_quarantine_db(quarantine_db)
        flash('File removed from quarantine')
    
    return redirect(url_for('quarantine'))

@app.route('/quarantine/restore/<int:file_id>', methods=['POST'])
@login_required
def restore_quarantined_file(file_id):
    quarantine_db = load_quarantine_db()
    
    if file_id < len(quarantine_db["quarantined_files"]):
        # In a real app, this would restore the file to its original location
        flash('File restoration would happen here in a real implementation')
        
    return redirect(url_for('quarantine'))

@app.route('/scan-file', methods=['GET', 'POST'])
@login_required
def scan_file():
    if request.method == 'POST':
        if 'file' not in request.files:
            flash('No file part')
            return redirect(request.url)
        
        file = request.files['file']
        if file.filename == '':
            flash('No selected file')
            return redirect(request.url)
        
        if file:
            filename = secure_filename(file.filename)
            filepath = os.path.join(app.config['UPLOAD_FOLDER'], filename)
            file.save(filepath)
            
            # Scan the file
            is_suspicious = scanner.scan_file(filepath)
            if is_suspicious:
                ai_result = ai_detector.analyze(filepath)
                if ai_result["is_malicious"]:
                    # Add to quarantine
                    quarantine_db = load_quarantine_db()
                    quarantine_db["quarantined_files"].append({
                        "original_path": filepath,
                        "quarantine_path": filepath,
                        "filename": filename,
                        "threat_type": ai_result["threat_type"],
                        "confidence": ai_result["confidence"],
                        "date_quarantined": datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
                        "file_size": os.path.getsize(filepath)
                    })
                    save_quarantine_db(quarantine_db)
                    system_stats['threats_detected'] += 1
                    system_stats['files_quarantined'] += 1
                    
                    return render_template('scan_result.html', 
                                          filename=filename,
                                          is_malicious=True,
                                          threat_type=ai_result["threat_type"],
                                          confidence=ai_result["confidence"],
                                          theme='dark')
            
            # Update stats
            system_stats['scans_performed'] += 1
            system_stats['last_scan'] = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
            
            return render_template('scan_result.html', 
                                  filename=filename,
                                  is_malicious=False,
                                  theme='dark')
    
    return render_template('scan_file.html', theme='dark')

@app.route('/settings')
@login_required
def settings():
    return render_template('settings.html', theme='dark')

@app.route('/updates')
@login_required
def updates():
    # Get version info
    with open(updater.version_file, 'r') as f:
        version_data = json.load(f)
    
    current_version = version_data.get('version', '1.0.0')
    last_check = version_data.get('last_check', datetime.datetime.now().isoformat())
    
    # Format the last check date
    try:
        last_check_date = datetime.datetime.fromisoformat(last_check)
        last_check_formatted = last_check_date.strftime("%Y-%m-%d %H:%M:%S")
    except:
        last_check_formatted = "Never"
    
    # Get initial release date
    initial_date = datetime.datetime.now().strftime("%Y-%m-%d")
    
    return render_template('updates.html', 
                          current_version=current_version,
                          last_check=last_check_formatted,
                          initial_date=initial_date, theme='dark')

@app.route('/api/stats')
@login_required
def api_stats():
    quarantine_db = load_quarantine_db()
    
    # Get threat types distribution
    threat_types = {}
    for file in quarantine_db["quarantined_files"]:
        threat_type = file.get("threat_type", "Unknown")
        threat_types[threat_type] = threat_types.get(threat_type, 0) + 1
    
    return jsonify({
        'system_stats': system_stats,
        'quarantine_count': len(quarantine_db["quarantined_files"]),
        'threat_types': threat_types
    })

@app.route('/api/safe-vendors')
@login_required
def api_safe_vendors():
    return jsonify({
        'safe_vendors': ai_detector.safe_vendors
    })

@app.route('/api/add-safe-vendor', methods=['POST'])
@login_required
def api_add_safe_vendor():
    data = request.json
    vendor = data.get('vendor', '').lower().strip()
    
    if vendor and vendor not in ai_detector.safe_vendors:
        ai_detector.safe_vendors.append(vendor)
        return jsonify({'success': True, 'message': f'Added {vendor} to safe vendors'})
    
    return jsonify({'success': False, 'message': 'Invalid vendor name or already exists'})

@app.route('/api/remove-safe-vendor', methods=['POST'])
@login_required
def api_remove_safe_vendor():
    data = request.json
    vendor = data.get('vendor', '').lower().strip()
    
    if vendor in ai_detector.safe_vendors:
        ai_detector.safe_vendors.remove(vendor)
        return jsonify({'success': True, 'message': f'Removed {vendor} from safe vendors'})
    
    return jsonify({'success': False, 'message': 'Vendor not found'})

@app.route('/api/safe-programs')
@login_required
def api_safe_programs():
    safe_programs = []
    safe_programs_path = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), 'safe_programs.txt')
    
    if os.path.exists(safe_programs_path):
        with open(safe_programs_path, 'r') as f:
            for line in f:
                line = line.strip()
                if line and not line.startswith('#'):
                    safe_programs.append(line)
    
    return jsonify({'safe_programs': safe_programs})

@app.route('/api/add-safe-program', methods=['POST'])
@login_required
def api_add_safe_program():
    data = request.json
    program_path = data.get('program_path', '').strip()
    
    if not program_path:
        return jsonify({'success': False, 'message': 'Invalid program path'})
    
    safe_programs_path = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), 'safe_programs.txt')
    
    with open(safe_programs_path, 'a') as f:
        f.write(f'\n{program_path}')
    
    # Reload whitelist
    ai_detector.whitelist = ai_detector._load_whitelist()
    
    return jsonify({'success': True, 'message': f'Added {program_path} to safe programs'})

@app.route('/api/check-updates')
@login_required
def api_check_updates():
    update_info = updater.check_for_updates()
    
    # For demo purposes, simulate an available update
    if not update_info['available']:
        update_info = {
            'available': True,
            'current_version': updater.current_version,
            'latest_version': '1.1.0',
            'download_url': 'https://example.com/speedsfv/update.zip',
            'release_notes': 'New features:\n- Improved AI detection\n- Reduced false positives\n- Added force update feature\n- Bug fixes and performance improvements'
        }
    
    # Update last check time
    updater.save_version_info()
    
    return jsonify(update_info)

@app.route('/api/install-update')
@login_required
def api_install_update():
    # In a real implementation, this would download and install the update
    # For demo purposes, simulate a successful update
    return jsonify({
        'success': True,
        'message': 'Update installed successfully'
    })

@app.route('/api/force-update')
@login_required
def api_force_update():
    # In a real implementation, this would set a flag in a database or send a message to clients
    # For demo purposes, simulate a successful force update
    return jsonify({
        'success': True,
        'message': 'Force update initiated'
    })

@app.route('/api/create-backup')
@login_required
def api_create_backup():
    backup_path = updater.create_backup()
    
    if backup_path:
        return jsonify({
            'success': True,
            'message': 'Backup created successfully',
            'backup_file': os.path.basename(backup_path)
        })
    else:
        return jsonify({
            'success': False,
            'message': 'Failed to create backup'
        })

@app.route('/api/list-backups')
@login_required
def api_list_backups():
    backups = []
    
    for backup_file in glob.glob(os.path.join(updater.backup_dir, 'backup_*.zip')):
        filename = os.path.basename(backup_file)
        # Extract date from filename (format: backup_1.0.0_20250321_155724.zip)
        date_str = filename.split('_')[2] + '_' + filename.split('_')[3].split('.')[0]
        try:
            date = datetime.datetime.strptime(date_str, '%Y%m%d_%H%M%S')
            date_formatted = date.strftime('%Y-%m-%d %H:%M:%S')
        except:
            date_formatted = 'Unknown'
        
        backups.append({
            'filename': filename,
            'date': date_formatted,
            'path': backup_file
        })
    
    # Sort backups by date (newest first)
    backups.sort(key=lambda x: x['filename'], reverse=True)
    
    return jsonify({'backups': backups})

@app.route('/api/restore-backup', methods=['POST'])
@login_required
def api_restore_backup():
    data = request.json
    backup_file = data.get('backup')
    
    if not backup_file:
        return jsonify({'success': False, 'message': 'No backup file specified'})
    
    backup_path = os.path.join(updater.backup_dir, backup_file)
    if not os.path.exists(backup_path):
        return jsonify({'success': False, 'message': 'Backup file not found'})
    
    success, message = updater.restore_backup(backup_path)
    
    return jsonify({
        'success': success,
        'message': message
    })

@app.route('/api/ai-settings', methods=['GET', 'POST'])
@login_required
def api_ai_settings():
    if request.method == 'GET':
        return jsonify({
            'sensitivity': ai_detector.sensitivity,
            'ai_mode': ai_detector.ai_mode,
            'behavioral_analysis_enabled': ai_detector.behavioral_analysis_enabled,
            'heuristic_detection_enabled': ai_detector.heuristic_detection_enabled,
            'cloud_analysis_enabled': ai_detector.cloud_analysis_enabled
        })
    else:
        data = request.json
        
        # Update AI settings
        if 'sensitivity' in data:
            ai_detector.sensitivity = int(data['sensitivity'])
        
        if 'ai_mode' in data:
            ai_detector.ai_mode = data['ai_mode']
        
        if 'behavioral_analysis_enabled' in data:
            ai_detector.behavioral_analysis_enabled = data['behavioral_analysis_enabled']
        
        if 'heuristic_detection_enabled' in data:
            ai_detector.heuristic_detection_enabled = data['heuristic_detection_enabled']
        
        if 'cloud_analysis_enabled' in data:
            ai_detector.cloud_analysis_enabled = data['cloud_analysis_enabled']
        
        return jsonify({
            'success': True,
            'message': 'AI settings updated successfully'
        })

def open_browser(url):
    """Open the browser to the specified URL"""
    import webbrowser
    webbrowser.open(url)

def run_web_server():
    """Run the web server"""
    try:
        # Temporarily disable ngrok for testing
        # from pyngrok import ngrok
        # public_url = ngrok.connect(5000).public_url
        # print(f"\n* SpeedSFV Admin Panel is running at: {public_url}")
        print(f"\n* SpeedSFV Admin Panel is running at: http://localhost:5000")
        print(f"* Username: admin")
        print(f"* Password: admin123")
        print("\n* Press Ctrl+C to quit")
        
        # Open browser after a short delay
        threading.Timer(1.5, open_browser, args=["http://localhost:5000"]).start()
    except Exception as e:
        print(f"\n* Failed to start server: {str(e)}")
        print(f"* SpeedSFV Admin Panel is running at: http://localhost:5000")
        print(f"* Username: admin")
        print(f"* Password: admin123")
        print("\n* Press Ctrl+C to quit")
        
        # Open browser after a short delay
        threading.Timer(1.5, open_browser, args=["http://localhost:5000"]).start()
    
    # Run the Flask app
    socketio.run(app, host='0.0.0.0', port=5000, debug=False)

if __name__ == '__main__':
    # Create a thread for the web server
    run_web_server()
