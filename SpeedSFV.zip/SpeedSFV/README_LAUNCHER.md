# SpeedSFV Launcher Options

This document explains the different ways to launch SpeedSFV Antivirus.

## Simple Version (Recommended)

The simple version uses only standard Python libraries and doesn't require any additional dependencies. This is the most reliable way to run SpeedSFV.

To use the simple version:
1. Double-click on `SimpleSpeedSFV.bat`
2. The application will start immediately without installing any dependencies

### Features of the Simple Version
- Works with standard Python installation
- No dependency installation required
- Dark mode and light mode themes
- All core scanning functionality
- Quick, full, and custom scans

## Full Version

The full version includes additional features but requires external dependencies (PyQt6, psutil, requests).

To use the full version:
1. Double-click on `RunSpeedSFV.bat` or `SpeedSFV.bat`
2. The launcher will check if dependencies are installed and install them if needed
3. The application will start once dependencies are installed

### Troubleshooting Dependency Installation

If you experience issues with dependency installation:

1. **Manual Installation**: Run the following commands in a terminal:
   ```
   pip install PyQt6==6.6.1
   pip install psutil==5.9.6
   pip install requests==2.31.0
   ```

2. **Stuck Progress Bar**: If the installation progress bar gets stuck, cancel the installation and try running the simple version instead.

3. **Python Not Found**: Make sure Python is installed and added to your PATH environment variable.

## Creating a Desktop Shortcut

To create a desktop shortcut:
1. Right-click on `SimpleSpeedSFV.bat` or `RunSpeedSFV.bat`
2. Select "Create shortcut"
3. Move the shortcut to your desktop
