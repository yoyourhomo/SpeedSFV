import os
import sys
import time
import random
import hashlib
import threading
import tkinter as tk
from tkinter import ttk, filedialog, messagebox, Menu, simpledialog
import json
import shutil
import uuid
import datetime
import webbrowser
import socket
import platform
import subprocess

class SimpleScanner:
    def __init__(self):
        self.suspicious_extensions = [
            ".exe", ".dll", ".bat", ".cmd", ".ps1", ".vbs", ".js", 
            ".jar", ".scr", ".pif", ".hta", ".com"
        ]
        
        self.malware_patterns = [
            b"X5O!P%@AP[4\\PZX54(P^)7CC)7}$EICAR",  # EICAR test string
            b"CreateRemoteThread",
            b"VirtualAlloc",
            b"ShellExecute",
            b"WScript.Shell",
            b"HKEY_LOCAL_MACHINE\\Software\\Microsoft\\Windows\\CurrentVersion\\Run"
        ]
        
        # Load safe programs list
        self.safe_programs = self.load_safe_programs()
    
    def load_safe_programs(self):
        """Load the list of safe programs from a file"""
        safe_programs = []
        safe_file = os.path.join(os.path.dirname(os.path.abspath(__file__)), "safe_programs.txt")
        
        if os.path.exists(safe_file):
            try:
                with open(safe_file, "r") as f:
                    for line in f:
                        line = line.strip()
                        if line and not line.startswith("#"):
                            safe_programs.append(line)
            except Exception:
                pass
        
        return safe_programs
    
    def save_safe_programs(self, safe_programs):
        """Save the list of safe programs to a file"""
        safe_file = os.path.join(os.path.dirname(os.path.abspath(__file__)), "safe_programs.txt")
        
        try:
            with open(safe_file, "w") as f:
                f.write("# SpeedSFV Safe Programs List\n")
                f.write("# Add one program path per line\n\n")
                for program in safe_programs:
                    f.write(f"{program}\n")
            return True
        except Exception:
            return False
    
    def scan_file(self, file_path):
        """Simplified scanner that doesn't require external dependencies"""
        try:
            # Check if the file is in the safe programs list
            if file_path in self.safe_programs:
                return False
                
            # Skip very large files
            if os.path.getsize(file_path) > 10 * 1024 * 1024:  # 10 MB
                return False
            
            # Check if the file extension is suspicious
            _, ext = os.path.splitext(file_path.lower())
            is_executable = ext in self.suspicious_extensions
            
            # For demo purposes, randomly flag some executable files
            if is_executable and random.random() < 0.005:
                return True
            
            # For small files, check content for known patterns
            if os.path.getsize(file_path) < 1 * 1024 * 1024:  # 1 MB
                try:
                    with open(file_path, "rb") as f:
                        content = f.read(1024)  # First 1KB
                        
                        # Check for known malware patterns
                        for pattern in self.malware_patterns:
                            if pattern in content:
                                return True
                except (PermissionError, OSError):
                    pass
            
            return False
        except Exception:
            return False

class QuarantineManager:
    def __init__(self):
        self.quarantine_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), "quarantine")
        self.db_file = os.path.join(self.quarantine_dir, "quarantine_db.json")
        
        # Ensure quarantine directory exists
        if not os.path.exists(self.quarantine_dir):
            os.makedirs(self.quarantine_dir)
        
        # Ensure database file exists
        if not os.path.exists(self.db_file):
            with open(self.db_file, "w") as f:
                json.dump({"quarantined_files": []}, f)
    
    def load_quarantine_db(self):
        """Load the quarantine database"""
        try:
            with open(self.db_file, "r") as f:
                return json.load(f)
        except Exception:
            return {"quarantined_files": []}
    
    def save_quarantine_db(self, db):
        """Save the quarantine database"""
        try:
            with open(self.db_file, "w") as f:
                json.dump(db, f, indent=4)
            return True
        except Exception:
            return False
    
    def quarantine_file(self, file_path, threat_type, confidence):
        """Move a file to quarantine"""
        try:
            # Generate a unique ID for the quarantined file
            file_id = str(uuid.uuid4())
            
            # Get the file name
            file_name = os.path.basename(file_path)
            
            # Create a quarantine entry
            quarantine_entry = {
                "id": file_id,
                "original_path": file_path,
                "file_name": file_name,
                "threat_type": threat_type,
                "confidence": confidence,
                "quarantine_date": datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
                "quarantine_file": os.path.join(self.quarantine_dir, file_id)
            }
            
            # Copy the file to quarantine
            shutil.copy2(file_path, quarantine_entry["quarantine_file"])
            
            # Add the entry to the database
            db = self.load_quarantine_db()
            db["quarantined_files"].append(quarantine_entry)
            self.save_quarantine_db(db)
            
            return True
        except Exception as e:
            print(f"Error quarantining file: {e}")
            return False
    
    def delete_quarantined_file(self, file_id):
        """Delete a file from quarantine"""
        try:
            db = self.load_quarantine_db()
            
            # Find the entry
            for i, entry in enumerate(db["quarantined_files"]):
                if entry["id"] == file_id:
                    # Delete the quarantined file
                    if os.path.exists(entry["quarantine_file"]):
                        os.remove(entry["quarantine_file"])
                    
                    # Remove the entry from the database
                    db["quarantined_files"].pop(i)
                    self.save_quarantine_db(db)
                    return True
            
            return False
        except Exception as e:
            print(f"Error deleting quarantined file: {e}")
            return False
    
    def restore_quarantined_file(self, file_id):
        """Restore a file from quarantine"""
        try:
            db = self.load_quarantine_db()
            
            # Find the entry
            for i, entry in enumerate(db["quarantined_files"]):
                if entry["id"] == file_id:
                    # Check if the original path exists
                    original_dir = os.path.dirname(entry["original_path"])
                    if not os.path.exists(original_dir):
                        os.makedirs(original_dir, exist_ok=True)
                    
                    # Copy the file back to its original location
                    shutil.copy2(entry["quarantine_file"], entry["original_path"])
                    
                    # Remove the entry from the database
                    db["quarantined_files"].pop(i)
                    self.save_quarantine_db(db)
                    return True
            
            return False
        except Exception as e:
            print(f"Error restoring quarantined file: {e}")
            return False
    
    def get_quarantined_files(self):
        """Get all quarantined files"""
        db = self.load_quarantine_db()
        return db["quarantined_files"]
    
    def delete_all_quarantined_files(self):
        """Delete all files from quarantine"""
        try:
            db = self.load_quarantine_db()
            
            # Delete all quarantined files
            for entry in db["quarantined_files"]:
                if os.path.exists(entry["quarantine_file"]):
                    os.remove(entry["quarantine_file"])
            
            # Clear the database
            db["quarantined_files"] = []
            self.save_quarantine_db(db)
            return True
        except Exception as e:
            print(f"Error deleting all quarantined files: {e}")
            return False

class SpeedSFVApp:
    def __init__(self, root):
        self.root = root
        self.root.title("SpeedSFV Antivirus")
        self.root.geometry("800x600")
        self.root.minsize(800, 600)
        
        # Set up the scanner
        self.scanner = SimpleScanner()
        self.quarantine_manager = QuarantineManager()
        
        # Set up variables
        self.scan_running = False
        self.scan_thread = None
        self.scan_results = []
        self.dark_mode = True
        self.admin_mode = False
        self.admin_password = "admin123"  # Simple password for demo purposes
        
        # Create main frame
        self.main_frame = ttk.Frame(root, padding=20)
        self.main_frame.pack(fill=tk.BOTH, expand=True)
        
        # Create header
        header_frame = ttk.Frame(self.main_frame)
        header_frame.pack(fill=tk.X, pady=(0, 20))
        
        title_label = ttk.Label(header_frame, text="SpeedSFV Antivirus", font=("Arial", 18, "bold"))
        title_label.pack(side=tk.LEFT)
        
        # Admin button
        self.admin_button = ttk.Button(header_frame, text="Admin Panel", command=self.show_admin_login)
        self.admin_button.pack(side=tk.RIGHT, padx=(0, 10))
        
        # Theme toggle button
        self.theme_button = ttk.Button(header_frame, text="Light Mode", command=self.toggle_theme)
        self.theme_button.pack(side=tk.RIGHT)
        
        # Create notebook (tabs)
        self.notebook = ttk.Notebook(self.main_frame)
        self.notebook.pack(fill=tk.BOTH, expand=True)
        
        # Dashboard tab
        self.dashboard_tab = ttk.Frame(self.notebook, padding=10)
        self.notebook.add(self.dashboard_tab, text="Dashboard")
        
        status_frame = ttk.LabelFrame(self.dashboard_tab, text="Protection Status", padding=10)
        status_frame.pack(fill=tk.X, pady=(0, 20))
        
        self.status_label = ttk.Label(status_frame, text="Protection Active", font=("Arial", 12))
        self.status_label.pack(anchor=tk.W)
        
        self.last_scan_label = ttk.Label(status_frame, text="Last Scan: Never")
        self.last_scan_label.pack(anchor=tk.W)
        
        # Quick action buttons
        actions_frame = ttk.Frame(self.dashboard_tab)
        actions_frame.pack(fill=tk.X, pady=(0, 20))
        
        quick_scan_btn = ttk.Button(actions_frame, text="Quick Scan", command=lambda: self.start_scan("quick"))
        quick_scan_btn.pack(side=tk.LEFT, padx=(0, 10))
        
        full_scan_btn = ttk.Button(actions_frame, text="Full Scan", command=lambda: self.start_scan("full"))
        full_scan_btn.pack(side=tk.LEFT, padx=(0, 10))
        
        custom_scan_btn = ttk.Button(actions_frame, text="Custom Scan", command=self.select_custom_scan)
        custom_scan_btn.pack(side=tk.LEFT)
        
        # Scanner tab
        self.scanner_tab = ttk.Frame(self.notebook, padding=10)
        self.notebook.add(self.scanner_tab, text="Scanner")
        
        scan_options_frame = ttk.Frame(self.scanner_tab)
        scan_options_frame.pack(fill=tk.X, pady=(0, 10))
        
        ttk.Label(scan_options_frame, text="Scan Type:").pack(side=tk.LEFT, padx=(0, 5))
        
        self.scan_type = tk.StringVar(value="quick")
        scan_type_combo = ttk.Combobox(scan_options_frame, textvariable=self.scan_type, 
                                      values=["quick", "full", "custom"], state="readonly", width=10)
        scan_type_combo.pack(side=tk.LEFT, padx=(0, 10))
        
        self.path_button = ttk.Button(scan_options_frame, text="Select Path", command=self.select_custom_scan)
        self.path_button.pack(side=tk.LEFT, padx=(0, 10))
        
        start_scan_btn = ttk.Button(scan_options_frame, text="Start Scan", command=self.start_scan_from_combo)
        start_scan_btn.pack(side=tk.LEFT)
        
        # Progress frame
        progress_frame = ttk.Frame(self.scanner_tab)
        progress_frame.pack(fill=tk.X, pady=(0, 10))
        
        self.progress_bar = ttk.Progressbar(progress_frame, length=100, mode="determinate")
        self.progress_bar.pack(fill=tk.X, pady=(0, 5))
        
        self.current_file_label = ttk.Label(progress_frame, text="Ready to scan")
        self.current_file_label.pack(anchor=tk.W)
        
        # Results frame
        results_frame = ttk.LabelFrame(self.scanner_tab, text="Scan Results", padding=10)
        results_frame.pack(fill=tk.BOTH, expand=True)
        
        self.results_text = tk.Text(results_frame, wrap=tk.WORD, height=10)
        self.results_text.pack(fill=tk.BOTH, expand=True)
        
        # Settings tab
        self.settings_tab = ttk.Frame(self.notebook, padding=10)
        self.notebook.add(self.settings_tab, text="Settings")
        
        # Protection settings
        protection_frame = ttk.LabelFrame(self.settings_tab, text="Protection Settings", padding=10)
        protection_frame.pack(fill=tk.X, pady=(0, 20))
        
        self.realtime_var = tk.BooleanVar(value=True)
        realtime_check = ttk.Checkbutton(protection_frame, text="Real-time Protection", variable=self.realtime_var)
        realtime_check.pack(anchor=tk.W)
        
        self.startup_var = tk.BooleanVar(value=True)
        startup_check = ttk.Checkbutton(protection_frame, text="Start with Windows", variable=self.startup_var)
        startup_check.pack(anchor=tk.W)
        
        # Scan settings
        scan_settings_frame = ttk.LabelFrame(self.settings_tab, text="Scan Settings", padding=10)
        scan_settings_frame.pack(fill=tk.X)
        
        self.archive_var = tk.BooleanVar(value=True)
        archive_check = ttk.Checkbutton(scan_settings_frame, text="Scan Archive Files", variable=self.archive_var)
        archive_check.pack(anchor=tk.W)
        
        # Admin tab (will be added dynamically when admin logs in)
        self.admin_tab = None
        
        # Status bar
        self.status_bar = ttk.Label(root, text="SpeedSFV Antivirus | Ready", relief=tk.SUNKEN, anchor=tk.W)
        self.status_bar.pack(side=tk.BOTTOM, fill=tk.X)
        
        # Apply dark theme by default
        self.apply_dark_theme()
        
        # Custom scan path
        self.custom_scan_path = None
        
        # Bind close event
        self.root.protocol("WM_DELETE_WINDOW", self.on_close)
    
    def toggle_theme(self):
        if self.dark_mode:
            self.apply_light_theme()
            self.theme_button.config(text="Dark Mode")
            self.dark_mode = False
        else:
            self.apply_dark_theme()
            self.theme_button.config(text="Light Mode")
            self.dark_mode = True
    
    def apply_dark_theme(self):
        style = ttk.Style()
        style.theme_use('clam')
        
        # Configure colors
        style.configure('.', background='#333333', foreground='#ffffff')
        style.configure('TFrame', background='#333333')
        style.configure('TLabel', background='#333333', foreground='#ffffff')
        style.configure('TLabelframe', background='#333333', foreground='#ffffff')
        style.configure('TLabelframe.Label', background='#333333', foreground='#ffffff')
        style.configure('TButton', background='#555555', foreground='#ffffff')
        style.configure('TCheckbutton', background='#333333', foreground='#ffffff')
        style.configure('TNotebook', background='#333333', foreground='#ffffff')
        style.configure('TNotebook.Tab', background='#555555', foreground='#ffffff')
        
        # Configure the text widget
        self.results_text.config(bg='#222222', fg='#ffffff', insertbackground='#ffffff')
        
        # Configure the root window
        self.root.configure(bg='#333333')
        self.status_bar.configure(background='#222222', foreground='#ffffff')
    
    def apply_light_theme(self):
        style = ttk.Style()
        style.theme_use('clam')
        
        # Configure colors
        style.configure('.', background='#f0f0f0', foreground='#000000')
        style.configure('TFrame', background='#f0f0f0')
        style.configure('TLabel', background='#f0f0f0', foreground='#000000')
        style.configure('TLabelframe', background='#f0f0f0', foreground='#000000')
        style.configure('TLabelframe.Label', background='#f0f0f0', foreground='#000000')
        style.configure('TButton', background='#e0e0e0', foreground='#000000')
        style.configure('TCheckbutton', background='#f0f0f0', foreground='#000000')
        style.configure('TNotebook', background='#f0f0f0', foreground='#000000')
        style.configure('TNotebook.Tab', background='#e0e0e0', foreground='#000000')
        
        # Configure the text widget
        self.results_text.config(bg='#ffffff', fg='#000000', insertbackground='#000000')
        
        # Configure the root window
        self.root.configure(bg='#f0f0f0')
        self.status_bar.configure(background='#e0e0e0', foreground='#000000')
    
    def select_custom_scan(self):
        path = filedialog.askdirectory(title="Select Directory to Scan")
        if path:
            self.custom_scan_path = path
            self.scan_type.set("custom")
            self.status_bar.config(text=f"Selected path: {path}")
    
    def start_scan_from_combo(self):
        scan_type = self.scan_type.get()
        self.start_scan(scan_type)
    
    def start_scan(self, scan_type=None):
        if self.scan_running:
            messagebox.showwarning("Scan in Progress", "A scan is already running. Please wait for it to complete.")
            return
        
        if scan_type:
            self.scan_type.set(scan_type)
        
        scan_type = self.scan_type.get()
        
        if scan_type == "custom" and not self.custom_scan_path:
            self.select_custom_scan()
            if not self.custom_scan_path:
                return
        
        # Clear previous results
        self.results_text.delete(1.0, tk.END)
        self.progress_bar["value"] = 0
        self.current_file_label.config(text="Starting scan...")
        self.scan_results = []
        
        # Switch to scanner tab
        self.notebook.select(1)  # Index 1 is the scanner tab
        
        # Start scan in a separate thread
        self.scan_running = True
        self.scan_thread = threading.Thread(target=self.run_scan)
        self.scan_thread.daemon = True
        self.scan_thread.start()
        
        # Update status
        self.status_bar.config(text=f"{scan_type.title()} scan in progress...")
    
    def run_scan(self):
        scan_type = self.scan_type.get()
        threats = []
        
        try:
            if scan_type == "quick":
                paths = [
                    os.path.join(os.environ.get("SYSTEMROOT", "C:\\Windows"), "System32"),
                    os.path.join(os.environ.get("USERPROFILE", "C:\\Users\\User"), "Downloads"),
                    os.path.join(os.environ.get("USERPROFILE", "C:\\Users\\User"), "Desktop"),
                    os.path.join(os.environ.get("APPDATA", "C:\\Users\\User\\AppData\\Roaming"))
                ]
                
                # Limit files to scan
                max_files = 500
                files_to_scan = []
                
                for path in paths:
                    if not os.path.exists(path):
                        continue
                    for root, _, files in os.walk(path):
                        for file in files:
                            full_path = os.path.join(root, file)
                            files_to_scan.append(full_path)
                            if len(files_to_scan) >= max_files:
                                break
                        if len(files_to_scan) >= max_files:
                            break
                    if len(files_to_scan) >= max_files:
                        break
            
            elif scan_type == "full":
                # Get all drives
                drives = []
                for letter in "CDEFGHIJKLMNOPQRSTUVWXYZ":
                    if os.path.exists(f"{letter}:\\"):
                        drives.append(f"{letter}:\\")
                
                # Limit files to scan
                max_files = 1000
                files_to_scan = []
                
                for drive in drives:
                    for root, _, files in os.walk(drive):
                        for file in files:
                            full_path = os.path.join(root, file)
                            files_to_scan.append(full_path)
                            if len(files_to_scan) >= max_files:
                                break
                        if len(files_to_scan) >= max_files:
                            break
                    if len(files_to_scan) >= max_files:
                        break
            
            elif scan_type == "custom" and self.custom_scan_path:
                # Limit files to scan
                max_files = 750
                files_to_scan = []
                
                for root, _, files in os.walk(self.custom_scan_path):
                    for file in files:
                        full_path = os.path.join(root, file)
                        files_to_scan.append(full_path)
                        if len(files_to_scan) >= max_files:
                            break
                    if len(files_to_scan) >= max_files:
                        break
            
            # Scan the files
            total_files = len(files_to_scan)
            
            for i, file_path in enumerate(files_to_scan):
                if not self.scan_running:
                    break
                
                # Update UI
                self.update_ui(file_path, i, total_files)
                
                # Scan the file
                is_threat = self.scanner.scan_file(file_path)
                if is_threat:
                    threats.append({
                        "path": file_path,
                        "threat_type": self.get_random_threat_type(),
                        "confidence": random.randint(70, 99)
                    })
                    
                    # Update results in real-time
                    self.update_results(f"THREAT: {file_path} - {threats[-1]['threat_type']} "
                                      f"(Confidence: {threats[-1]['confidence']}%)\n")
            
            # Scan completed
            self.scan_completed(threats)
            
        except Exception as e:
            self.update_results(f"Error during scan: {str(e)}\n")
            self.scan_completed([])
    
    def update_ui(self, file_path, current, total):
        # This function updates the UI from the scan thread
        def update():
            self.current_file_label.config(text=f"Scanning: {file_path}")
            progress = int(((current + 1) / total) * 100) if total > 0 else 100
            self.progress_bar["value"] = progress
        
        self.root.after(0, update)
        time.sleep(0.001)  # Small delay to prevent UI freezing
    
    def update_results(self, text):
        # This function updates the results text from the scan thread
        def update():
            self.results_text.insert(tk.END, text)
            self.results_text.see(tk.END)
        
        self.root.after(0, update)
    
    def scan_completed(self, threats):
        # This function is called when the scan is completed
        def update():
            self.current_file_label.config(text="Scan completed")
            self.progress_bar["value"] = 100
            
            if not threats:
                self.update_results("No threats found.\n")
                messagebox.showinfo("Scan Completed", "No threats were found during the scan.")
            else:
                # Ask user what to do with threats
                self.show_threats_dialog(threats)
            
            # Update last scan time
            current_time = time.strftime("%Y-%m-%d %H:%M:%S")
            self.last_scan_label.config(text=f"Last Scan: {current_time}")
            
            # Update status
            self.status_bar.config(text="Scan completed")
            
            # Reset scan state
            self.scan_running = False
        
        self.root.after(0, update)
    
    def get_random_threat_type(self):
        threat_types = [
            "Trojan", "Ransomware", "Spyware", "Adware", "Worm", 
            "Keylogger", "Rootkit", "Backdoor", "Exploit", "Dropper"
        ]
        return random.choice(threat_types)
    
    def on_close(self):
        if self.scan_running:
            result = messagebox.askquestion(
                "Scan in Progress",
                "A scan is currently running. Are you sure you want to exit?",
                icon="warning"
            )
            if result == "no":
                return
            
            self.scan_running = False
            if self.scan_thread:
                self.scan_thread.join(0.1)
        
        self.root.destroy()
    
    def show_admin_login(self):
        """Show the admin login dialog"""
        login_window = tk.Toplevel(self.root)
        login_window.title("Admin Login")
        login_window.geometry("300x150")
        login_window.resizable(False, False)
        login_window.transient(self.root)
        login_window.grab_set()
        
        # Center the window
        login_window.update_idletasks()
        width = login_window.winfo_width()
        height = login_window.winfo_height()
        x = (login_window.winfo_screenwidth() // 2) - (width // 2)
        y = (login_window.winfo_screenheight() // 2) - (height // 2)
        login_window.geometry(f"{width}x{height}+{x}+{y}")
        
        # Apply theme
        if self.dark_mode:
            login_window.configure(bg='#333333')
        else:
            login_window.configure(bg='#f0f0f0')
        
        # Create a frame for the content
        frame = ttk.Frame(login_window, padding=20)
        frame.pack(fill=tk.BOTH, expand=True)
        
        # Create a label for the title
        title_label = ttk.Label(frame, text="Admin Login", font=("Arial", 12, "bold"))
        title_label.pack(pady=(0, 10))
        
        # Create a password entry
        password_frame = ttk.Frame(frame)
        password_frame.pack(fill=tk.X, pady=(0, 10))
        
        ttk.Label(password_frame, text="Password:").pack(side=tk.LEFT, padx=(0, 5))
        
        password_var = tk.StringVar()
        password_entry = ttk.Entry(password_frame, textvariable=password_var, show="*")
        password_entry.pack(side=tk.LEFT, fill=tk.X, expand=True)
        password_entry.focus_set()
        
        # Create buttons
        button_frame = ttk.Frame(frame)
        button_frame.pack(fill=tk.X)
        
        login_button = ttk.Button(button_frame, text="Login", 
                                command=lambda: self.check_admin_password(password_var.get(), login_window))
        login_button.pack(side=tk.RIGHT, padx=(5, 0))
        
        cancel_button = ttk.Button(button_frame, text="Cancel", command=login_window.destroy)
        cancel_button.pack(side=tk.RIGHT)
        
        # Bind Enter key to login
        login_window.bind("<Return>", lambda event: self.check_admin_password(password_var.get(), login_window))
    
    def check_admin_password(self, password, login_window):
        """Check the admin password"""
        if password == self.admin_password:
            self.admin_mode = True
            login_window.destroy()
            self.create_admin_tab()
            self.admin_button.config(text="Exit Admin Mode", command=self.exit_admin_mode)
            self.status_bar.config(text="SpeedSFV Antivirus | Admin Mode")
        else:
            messagebox.showerror("Error", "Incorrect password", parent=login_window)
    
    def exit_admin_mode(self):
        """Exit admin mode"""
        self.admin_mode = False
        if self.admin_tab:
            self.notebook.forget(self.admin_tab)
            self.admin_tab = None
        self.admin_button.config(text="Admin Panel", command=self.show_admin_login)
        self.status_bar.config(text="SpeedSFV Antivirus | Ready")
    
    def create_admin_tab(self):
        """Create the admin tab"""
        if self.admin_tab:
            self.notebook.forget(self.admin_tab)
        
        self.admin_tab = ttk.Frame(self.notebook, padding=10)
        self.notebook.add(self.admin_tab, text="Admin")
        self.notebook.select(self.admin_tab)
        
        # Create a notebook for admin sections
        admin_notebook = ttk.Notebook(self.admin_tab)
        admin_notebook.pack(fill=tk.BOTH, expand=True)
        
        # Safe Programs tab
        safe_programs_tab = ttk.Frame(admin_notebook, padding=10)
        admin_notebook.add(safe_programs_tab, text="Safe Programs")
        
        # Instructions
        ttk.Label(safe_programs_tab, text="Manage programs that should be considered safe during scans:", 
                 wraplength=700).pack(anchor=tk.W, pady=(0, 10))
        
        # List of safe programs
        list_frame = ttk.Frame(safe_programs_tab)
        list_frame.pack(fill=tk.BOTH, expand=True)
        
        # Create a listbox with scrollbar
        list_frame_inner = ttk.Frame(list_frame)
        list_frame_inner.pack(fill=tk.BOTH, expand=True, pady=(0, 10))
        
        scrollbar = ttk.Scrollbar(list_frame_inner)
        scrollbar.pack(side=tk.RIGHT, fill=tk.Y)
        
        self.safe_programs_listbox = tk.Listbox(list_frame_inner, yscrollcommand=scrollbar.set, 
                                              height=10, selectmode=tk.SINGLE)
        self.safe_programs_listbox.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
        
        scrollbar.config(command=self.safe_programs_listbox.yview)
        
        # Populate the listbox
        for program in self.scanner.safe_programs:
            self.safe_programs_listbox.insert(tk.END, program)
        
        # Buttons for managing safe programs
        button_frame = ttk.Frame(list_frame)
        button_frame.pack(fill=tk.X)
        
        add_button = ttk.Button(button_frame, text="Add Program", command=self.add_safe_program)
        add_button.pack(side=tk.LEFT, padx=(0, 5))
        
        remove_button = ttk.Button(button_frame, text="Remove Selected", command=self.remove_safe_program)
        remove_button.pack(side=tk.LEFT)
        
        # Advanced Settings tab
        advanced_tab = ttk.Frame(admin_notebook, padding=10)
        admin_notebook.add(advanced_tab, text="Advanced Settings")
        
        # Scan intensity
        intensity_frame = ttk.LabelFrame(advanced_tab, text="Scan Intensity", padding=10)
        intensity_frame.pack(fill=tk.X, pady=(0, 20))
        
        self.scan_intensity = tk.IntVar(value=2)
        ttk.Radiobutton(intensity_frame, text="Low - Faster scanning, less thorough", 
                       variable=self.scan_intensity, value=1).pack(anchor=tk.W)
        ttk.Radiobutton(intensity_frame, text="Medium - Balanced scanning (Default)", 
                       variable=self.scan_intensity, value=2).pack(anchor=tk.W)
        ttk.Radiobutton(intensity_frame, text="High - Thorough scanning, slower performance", 
                       variable=self.scan_intensity, value=3).pack(anchor=tk.W)
        
        # Detection sensitivity
        sensitivity_frame = ttk.LabelFrame(advanced_tab, text="Detection Sensitivity", padding=10)
        sensitivity_frame.pack(fill=tk.X, pady=(0, 20))
        
        self.detection_sensitivity = tk.IntVar(value=2)
        ttk.Radiobutton(sensitivity_frame, text="Low - Fewer false positives, may miss some threats", 
                       variable=self.detection_sensitivity, value=1).pack(anchor=tk.W)
        ttk.Radiobutton(sensitivity_frame, text="Medium - Balanced detection (Default)", 
                       variable=self.detection_sensitivity, value=2).pack(anchor=tk.W)
        ttk.Radiobutton(sensitivity_frame, text="High - More thorough detection, more false positives", 
                       variable=self.detection_sensitivity, value=3).pack(anchor=tk.W)
        
        # Admin password
        password_frame = ttk.LabelFrame(advanced_tab, text="Change Admin Password", padding=10)
        password_frame.pack(fill=tk.X)
        
        password_inner_frame = ttk.Frame(password_frame)
        password_inner_frame.pack(fill=tk.X, pady=(0, 10))
        
        ttk.Label(password_inner_frame, text="New Password:").pack(side=tk.LEFT, padx=(0, 5))
        
        self.new_password_var = tk.StringVar()
        new_password_entry = ttk.Entry(password_inner_frame, textvariable=self.new_password_var, show="*")
        new_password_entry.pack(side=tk.LEFT, fill=tk.X, expand=True)
        
        change_password_button = ttk.Button(password_frame, text="Change Password", 
                                          command=self.change_admin_password)
        change_password_button.pack(anchor=tk.E)
        
        # System tab
        system_tab = ttk.Frame(admin_notebook, padding=10)
        admin_notebook.add(system_tab, text="System")
        
        # System information
        system_info_frame = ttk.LabelFrame(system_tab, text="System Information", padding=10)
        system_info_frame.pack(fill=tk.X, pady=(0, 20))
        
        # Get system info
        python_version = f"Python Version: {sys.version.split()[0]}"
        os_info = f"Operating System: {sys.platform}"
        
        ttk.Label(system_info_frame, text=python_version).pack(anchor=tk.W)
        ttk.Label(system_info_frame, text=os_info).pack(anchor=tk.W)
        
        # Actions
        actions_frame = ttk.LabelFrame(system_tab, text="System Actions", padding=10)
        actions_frame.pack(fill=tk.X)
        
        ttk.Button(actions_frame, text="Export Logs", command=self.export_logs).pack(anchor=tk.W, pady=(0, 5))
        ttk.Button(actions_frame, text="Reset All Settings", command=self.reset_settings).pack(anchor=tk.W)
        
        # Quarantine tab
        quarantine_tab = ttk.Frame(admin_notebook, padding=10)
        admin_notebook.add(quarantine_tab, text="Quarantine")
        
        # Quarantine list
        list_frame = ttk.Frame(quarantine_tab)
        list_frame.pack(fill=tk.BOTH, expand=True)
        
        # Create a listbox with scrollbar
        list_frame_inner = ttk.Frame(list_frame)
        list_frame_inner.pack(fill=tk.BOTH, expand=True, pady=(0, 10))
        
        scrollbar = ttk.Scrollbar(list_frame_inner)
        scrollbar.pack(side=tk.RIGHT, fill=tk.Y)
        
        self.quarantine_listbox = tk.Listbox(list_frame_inner, yscrollcommand=scrollbar.set, 
                                              height=10, selectmode=tk.SINGLE)
        self.quarantine_listbox.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
        
        scrollbar.config(command=self.quarantine_listbox.yview)
        
        # Populate the listbox
        for file in self.quarantine_manager.get_quarantined_files():
            self.quarantine_listbox.insert(tk.END, file["file_name"])
        
        # Buttons for managing quarantine
        button_frame = ttk.Frame(list_frame)
        button_frame.pack(fill=tk.X)
        
        restore_button = ttk.Button(button_frame, text="Restore Selected", command=self.restore_quarantined_file)
        restore_button.pack(side=tk.LEFT, padx=(0, 5))
        
        delete_button = ttk.Button(button_frame, text="Delete Selected", command=self.delete_quarantined_file)
        delete_button.pack(side=tk.LEFT)
        
        delete_all_button = ttk.Button(button_frame, text="Delete All", command=self.delete_all_quarantined_files)
        delete_all_button.pack(side=tk.LEFT, padx=(5, 0))
        
        # Advanced Features tab
        advanced_features_tab = ttk.Frame(admin_notebook, padding=10)
        admin_notebook.add(advanced_features_tab, text="Advanced Features")
        
        # Create a notebook for advanced features
        advanced_features_notebook = ttk.Notebook(advanced_features_tab)
        advanced_features_notebook.pack(fill=tk.BOTH, expand=True)
        
        # Scheduled Scans tab
        scheduled_scans_tab = ttk.Frame(advanced_features_notebook, padding=10)
        advanced_features_notebook.add(scheduled_scans_tab, text="Scheduled Scans")
        
        # Enable scheduled scans
        enable_frame = ttk.Frame(scheduled_scans_tab)
        enable_frame.pack(fill=tk.X, pady=(0, 10))
        
        self.enable_scheduled_scans_var = tk.BooleanVar(value=False)
        ttk.Checkbutton(enable_frame, text="Enable Scheduled Scans", 
                      variable=self.enable_scheduled_scans_var).pack(anchor=tk.W)
        
        # Schedule settings
        schedule_frame = ttk.LabelFrame(scheduled_scans_tab, text="Schedule Settings")
        schedule_frame.pack(fill=tk.X, pady=(0, 10))
        
        # Frequency
        freq_frame = ttk.Frame(schedule_frame)
        freq_frame.pack(fill=tk.X, pady=5)
        
        ttk.Label(freq_frame, text="Frequency:").pack(side=tk.LEFT, padx=(0, 5))
        
        self.schedule_frequency_var = tk.StringVar(value="daily")
        freq_combo = ttk.Combobox(freq_frame, textvariable=self.schedule_frequency_var, 
                                state="readonly", width=15)
        freq_combo["values"] = ("daily", "weekly", "monthly")
        freq_combo.pack(side=tk.LEFT)
        
        # Time
        time_frame = ttk.Frame(schedule_frame)
        time_frame.pack(fill=tk.X, pady=5)
        
        ttk.Label(time_frame, text="Time:").pack(side=tk.LEFT, padx=(0, 5))
        
        self.schedule_hour_var = tk.StringVar(value="00")
        hour_combo = ttk.Combobox(time_frame, textvariable=self.schedule_hour_var, 
                                state="readonly", width=5)
        hour_combo["values"] = tuple(f"{i:02d}" for i in range(24))
        hour_combo.pack(side=tk.LEFT, padx=(0, 5))
        
        ttk.Label(time_frame, text=":").pack(side=tk.LEFT, padx=(0, 5))
        
        self.schedule_minute_var = tk.StringVar(value="00")
        minute_combo = ttk.Combobox(time_frame, textvariable=self.schedule_minute_var, 
                                  state="readonly", width=5)
        minute_combo["values"] = tuple(f"{i:02d}" for i in range(0, 60, 5))
        minute_combo.pack(side=tk.LEFT)
        
        # Scan type
        type_frame = ttk.Frame(schedule_frame)
        type_frame.pack(fill=tk.X, pady=5)
        
        ttk.Label(type_frame, text="Scan Type:").pack(side=tk.LEFT, padx=(0, 5))
        
        self.schedule_scan_type_var = tk.StringVar(value="quick")
        type_combo = ttk.Combobox(type_frame, textvariable=self.schedule_scan_type_var, 
                                state="readonly", width=15)
        type_combo["values"] = ("quick", "full", "custom")
        type_combo.pack(side=tk.LEFT)
        
        # Save button
        save_button = ttk.Button(scheduled_scans_tab, text="Save Schedule", 
                               command=self.save_schedule_settings)
        save_button.pack(anchor=tk.W, pady=(10, 0))
        
        # Network Protection tab
        network_tab = ttk.Frame(advanced_features_notebook, padding=10)
        advanced_features_notebook.add(network_tab, text="Network Protection")
        
        # Enable network protection
        network_enable_frame = ttk.Frame(network_tab)
        network_enable_frame.pack(fill=tk.X, pady=(0, 10))
        
        self.enable_network_protection_var = tk.BooleanVar(value=False)
        ttk.Checkbutton(network_enable_frame, text="Enable Network Protection", 
                      variable=self.enable_network_protection_var).pack(anchor=tk.W)
        
        # Firewall settings
        firewall_frame = ttk.LabelFrame(network_tab, text="Firewall Settings")
        firewall_frame.pack(fill=tk.X, pady=(0, 10))
        
        # Block suspicious connections
        block_frame = ttk.Frame(firewall_frame)
        block_frame.pack(fill=tk.X, pady=5)
        
        self.block_suspicious_connections_var = tk.BooleanVar(value=True)
        ttk.Checkbutton(block_frame, text="Block Suspicious Connections", 
                      variable=self.block_suspicious_connections_var).pack(anchor=tk.W)
        
        # Block unknown programs
        unknown_frame = ttk.Frame(firewall_frame)
        unknown_frame.pack(fill=tk.X, pady=5)
        
        self.block_unknown_programs_var = tk.BooleanVar(value=False)
        ttk.Checkbutton(unknown_frame, text="Block Unknown Programs", 
                      variable=self.block_unknown_programs_var).pack(anchor=tk.W)
        
        # Save button
        save_network_button = ttk.Button(network_tab, text="Save Network Settings", 
                                      command=self.save_network_settings)
        save_network_button.pack(anchor=tk.W, pady=(10, 0))
        
        # Real-time Protection tab
        realtime_tab = ttk.Frame(advanced_features_notebook, padding=10)
        advanced_features_notebook.add(realtime_tab, text="Real-time Protection")
        
        # Enable real-time protection
        realtime_enable_frame = ttk.Frame(realtime_tab)
        realtime_enable_frame.pack(fill=tk.X, pady=(0, 10))
        
        self.enable_realtime_protection_var = tk.BooleanVar(value=True)
        ttk.Checkbutton(realtime_enable_frame, text="Enable Real-time Protection", 
                      variable=self.enable_realtime_protection_var).pack(anchor=tk.W)
        
        # Protection settings
        protection_frame = ttk.LabelFrame(realtime_tab, text="Protection Settings")
        protection_frame.pack(fill=tk.X, pady=(0, 10))
        
        # Scan new files
        new_files_frame = ttk.Frame(protection_frame)
        new_files_frame.pack(fill=tk.X, pady=5)
        
        self.scan_new_files_var = tk.BooleanVar(value=True)
        ttk.Checkbutton(new_files_frame, text="Scan New Files", 
                      variable=self.scan_new_files_var).pack(anchor=tk.W)
        
        # Scan downloaded files
        download_frame = ttk.Frame(protection_frame)
        download_frame.pack(fill=tk.X, pady=5)
        
        self.scan_downloads_var = tk.BooleanVar(value=True)
        ttk.Checkbutton(download_frame, text="Scan Downloaded Files", 
                      variable=self.scan_downloads_var).pack(anchor=tk.W)
        
        # Scan USB drives
        usb_frame = ttk.Frame(protection_frame)
        usb_frame.pack(fill=tk.X, pady=5)
        
        self.scan_usb_var = tk.BooleanVar(value=True)
        ttk.Checkbutton(usb_frame, text="Scan USB Drives", 
                      variable=self.scan_usb_var).pack(anchor=tk.W)
        
        # Save button
        save_realtime_button = ttk.Button(realtime_tab, text="Save Protection Settings", 
                                       command=self.save_realtime_settings)
        save_realtime_button.pack(anchor=tk.W, pady=(10, 0))
        
        # Privacy Protection tab
        privacy_tab = ttk.Frame(advanced_features_notebook, padding=10)
        advanced_features_notebook.add(privacy_tab, text="Privacy Protection")
        
        # Enable privacy protection
        privacy_enable_frame = ttk.Frame(privacy_tab)
        privacy_enable_frame.pack(fill=tk.X, pady=(0, 10))
        
        self.enable_privacy_protection_var = tk.BooleanVar(value=False)
        ttk.Checkbutton(privacy_enable_frame, text="Enable Privacy Protection", 
                      variable=self.enable_privacy_protection_var).pack(anchor=tk.W)
        
        # Privacy settings
        privacy_frame = ttk.LabelFrame(privacy_tab, text="Privacy Settings")
        privacy_frame.pack(fill=tk.X, pady=(0, 10))
        
        # Block webcam access
        webcam_frame = ttk.Frame(privacy_frame)
        webcam_frame.pack(fill=tk.X, pady=5)
        
        self.block_webcam_var = tk.BooleanVar(value=False)
        ttk.Checkbutton(webcam_frame, text="Block Webcam Access", 
                      variable=self.block_webcam_var).pack(anchor=tk.W)
        
        # Block microphone access
        mic_frame = ttk.Frame(privacy_frame)
        mic_frame.pack(fill=tk.X, pady=5)
        
        self.block_mic_var = tk.BooleanVar(value=False)
        ttk.Checkbutton(mic_frame, text="Block Microphone Access", 
                      variable=self.block_mic_var).pack(anchor=tk.W)
        
        # Block keyloggers
        keylogger_frame = ttk.Frame(privacy_frame)
        keylogger_frame.pack(fill=tk.X, pady=5)
        
        self.block_keyloggers_var = tk.BooleanVar(value=True)
        ttk.Checkbutton(keylogger_frame, text="Block Keyloggers", 
                      variable=self.block_keyloggers_var).pack(anchor=tk.W)
        
        # Save button
        save_privacy_button = ttk.Button(privacy_tab, text="Save Privacy Settings", 
                                      command=self.save_privacy_settings)
        save_privacy_button.pack(anchor=tk.W, pady=(10, 0))
        
        # Web Protection tab
        web_tab = ttk.Frame(advanced_features_notebook, padding=10)
        advanced_features_notebook.add(web_tab, text="Web Protection")
        
        # Enable web protection
        web_enable_frame = ttk.Frame(web_tab)
        web_enable_frame.pack(fill=tk.X, pady=(0, 10))
        
        self.enable_web_protection_var = tk.BooleanVar(value=False)
        ttk.Checkbutton(web_enable_frame, text="Enable Web Protection", 
                      variable=self.enable_web_protection_var).pack(anchor=tk.W)
        
        # Web settings
        web_frame = ttk.LabelFrame(web_tab, text="Web Protection Settings")
        web_frame.pack(fill=tk.X, pady=(0, 10))
        
        # Block malicious websites
        malicious_frame = ttk.Frame(web_frame)
        malicious_frame.pack(fill=tk.X, pady=5)
        
        self.block_malicious_sites_var = tk.BooleanVar(value=True)
        ttk.Checkbutton(malicious_frame, text="Block Malicious Websites", 
                      variable=self.block_malicious_sites_var).pack(anchor=tk.W)
        
        # Block phishing websites
        phishing_frame = ttk.Frame(web_frame)
        phishing_frame.pack(fill=tk.X, pady=5)
        
        self.block_phishing_var = tk.BooleanVar(value=True)
        ttk.Checkbutton(phishing_frame, text="Block Phishing Websites", 
                      variable=self.block_phishing_var).pack(anchor=tk.W)
        
        # Block tracking
        tracking_frame = ttk.Frame(web_frame)
        tracking_frame.pack(fill=tk.X, pady=5)
        
        self.block_tracking_var = tk.BooleanVar(value=False)
        ttk.Checkbutton(tracking_frame, text="Block Tracking", 
                      variable=self.block_tracking_var).pack(anchor=tk.W)
        
        # Save button
        save_web_button = ttk.Button(web_tab, text="Save Web Protection Settings", 
                                   command=self.save_web_settings)
        save_web_button.pack(anchor=tk.W, pady=(10, 0))
        
        # System Optimization tab
        optimization_tab = ttk.Frame(advanced_features_notebook, padding=10)
        advanced_features_notebook.add(optimization_tab, text="System Optimization")
        
        # Enable system optimization
        optimization_enable_frame = ttk.Frame(optimization_tab)
        optimization_enable_frame.pack(fill=tk.X, pady=(0, 10))
        
        self.enable_optimization_var = tk.BooleanVar(value=False)
        ttk.Checkbutton(optimization_enable_frame, text="Enable System Optimization", 
                      variable=self.enable_optimization_var).pack(anchor=tk.W)
        
        # Optimization settings
        optimization_frame = ttk.LabelFrame(optimization_tab, text="Optimization Settings")
        optimization_frame.pack(fill=tk.X, pady=(0, 10))
        
        # Clean temporary files
        temp_frame = ttk.Frame(optimization_frame)
        temp_frame.pack(fill=tk.X, pady=5)
        
        self.clean_temp_files_var = tk.BooleanVar(value=True)
        ttk.Checkbutton(temp_frame, text="Clean Temporary Files", 
                      variable=self.clean_temp_files_var).pack(anchor=tk.W)
        
        # Defragment disk
        defrag_frame = ttk.Frame(optimization_frame)
        defrag_frame.pack(fill=tk.X, pady=5)
        
        self.defragment_disk_var = tk.BooleanVar(value=False)
        ttk.Checkbutton(defrag_frame, text="Defragment Disk", 
                      variable=self.defragment_disk_var).pack(anchor=tk.W)
        
        # Optimize startup
        startup_frame = ttk.Frame(optimization_frame)
        startup_frame.pack(fill=tk.X, pady=5)
        
        self.optimize_startup_var = tk.BooleanVar(value=True)
        ttk.Checkbutton(startup_frame, text="Optimize Startup", 
                      variable=self.optimize_startup_var).pack(anchor=tk.W)
        
        # Schedule optimization
        schedule_optimization_frame = ttk.Frame(optimization_frame)
        schedule_optimization_frame.pack(fill=tk.X, pady=5)
        
        self.schedule_optimization_var = tk.BooleanVar(value=False)
        ttk.Checkbutton(schedule_optimization_frame, text="Schedule Optimization", 
                      variable=self.schedule_optimization_var).pack(anchor=tk.W)
        
        # Save button
        save_optimization_button = ttk.Button(optimization_tab, text="Save Optimization Settings", 
                                           command=self.save_optimization_settings)
        save_optimization_button.pack(anchor=tk.W, pady=(10, 0))
        
        # Run optimization button
        run_optimization_button = ttk.Button(optimization_tab, text="Run Optimization Now", 
                                          command=self.run_optimization)
        run_optimization_button.pack(anchor=tk.W, pady=(5, 0))
        
        # Reports tab
        reports_tab = ttk.Frame(advanced_features_notebook, padding=10)
        advanced_features_notebook.add(reports_tab, text="Reports")
        
        # Reports settings
        reports_frame = ttk.LabelFrame(reports_tab, text="Report Settings")
        reports_frame.pack(fill=tk.X, pady=(0, 10))
        
        # Generate reports
        generate_frame = ttk.Frame(reports_frame)
        generate_frame.pack(fill=tk.X, pady=5)
        
        self.generate_reports_var = tk.BooleanVar(value=False)
        ttk.Checkbutton(generate_frame, text="Generate Weekly Reports", 
                      variable=self.generate_reports_var).pack(anchor=tk.W)
        
        # Email reports
        email_frame = ttk.Frame(reports_frame)
        email_frame.pack(fill=tk.X, pady=5)
        
        self.email_reports_var = tk.BooleanVar(value=False)
        ttk.Checkbutton(email_frame, text="Email Reports", 
                      variable=self.email_reports_var).pack(anchor=tk.W)
        
        # Email settings
        email_settings_frame = ttk.Frame(reports_frame)
        email_settings_frame.pack(fill=tk.X, pady=5)
        
        ttk.Label(email_settings_frame, text="Email Address:").pack(side=tk.LEFT, padx=(0, 5))
        
        self.email_address_var = tk.StringVar()
        ttk.Entry(email_settings_frame, textvariable=self.email_address_var).pack(side=tk.LEFT, fill=tk.X, expand=True)
        
        # Report types
        report_types_frame = ttk.LabelFrame(reports_tab, text="Report Types")
        report_types_frame.pack(fill=tk.X, pady=(0, 10))
        
        # Scan reports
        scan_reports_frame = ttk.Frame(report_types_frame)
        scan_reports_frame.pack(fill=tk.X, pady=5)
        
        self.scan_reports_var = tk.BooleanVar(value=True)
        ttk.Checkbutton(scan_reports_frame, text="Scan Reports", 
                      variable=self.scan_reports_var).pack(anchor=tk.W)
        
        # Threat reports
        threat_reports_frame = ttk.Frame(report_types_frame)
        threat_reports_frame.pack(fill=tk.X, pady=5)
        
        self.threat_reports_var = tk.BooleanVar(value=True)
        ttk.Checkbutton(threat_reports_frame, text="Threat Reports", 
                      variable=self.threat_reports_var).pack(anchor=tk.W)
        
        # System reports
        system_reports_frame = ttk.Frame(report_types_frame)
        system_reports_frame.pack(fill=tk.X, pady=5)
        
        self.system_reports_var = tk.BooleanVar(value=False)
        ttk.Checkbutton(system_reports_frame, text="System Reports", 
                      variable=self.system_reports_var).pack(anchor=tk.W)
        
        # Save button
        save_reports_button = ttk.Button(reports_tab, text="Save Report Settings", 
                                      command=self.save_reports_settings)
        save_reports_button.pack(anchor=tk.W, pady=(10, 0))
        
        # Generate report button
        generate_report_button = ttk.Button(reports_tab, text="Generate Report Now", 
                                         command=self.generate_report)
        generate_report_button.pack(anchor=tk.W, pady=(5, 0))
        
        # Update Management tab
        update_tab = ttk.Frame(advanced_features_notebook, padding=10)
        advanced_features_notebook.add(update_tab, text="Update Management")
        
        # Update settings
        update_frame = ttk.LabelFrame(update_tab, text="Update Settings")
        update_frame.pack(fill=tk.X, pady=(0, 10))
        
        # Auto update
        auto_update_frame = ttk.Frame(update_frame)
        auto_update_frame.pack(fill=tk.X, pady=5)
        
        self.auto_update_var = tk.BooleanVar(value=True)
        ttk.Checkbutton(auto_update_frame, text="Automatic Updates", 
                      variable=self.auto_update_var).pack(anchor=tk.W)
        
        # Update frequency
        update_freq_frame = ttk.Frame(update_frame)
        update_freq_frame.pack(fill=tk.X, pady=5)
        
        ttk.Label(update_freq_frame, text="Update Frequency:").pack(side=tk.LEFT, padx=(0, 5))
        
        self.update_frequency_var = tk.StringVar(value="daily")
        update_freq_combo = ttk.Combobox(update_freq_frame, textvariable=self.update_frequency_var, 
                                       state="readonly", width=15)
        update_freq_combo["values"] = ("hourly", "daily", "weekly")
        update_freq_combo.pack(side=tk.LEFT)
        
        # Update components
        update_components_frame = ttk.LabelFrame(update_tab, text="Update Components")
        update_components_frame.pack(fill=tk.X, pady=(0, 10))
        
        # Virus definitions
        virus_def_frame = ttk.Frame(update_components_frame)
        virus_def_frame.pack(fill=tk.X, pady=5)
        
        self.update_virus_def_var = tk.BooleanVar(value=True)
        ttk.Checkbutton(virus_def_frame, text="Virus Definitions", 
                      variable=self.update_virus_def_var).pack(anchor=tk.W)
        
        # Engine updates
        engine_frame = ttk.Frame(update_components_frame)
        engine_frame.pack(fill=tk.X, pady=5)
        
        self.update_engine_var = tk.BooleanVar(value=True)
        ttk.Checkbutton(engine_frame, text="Scanning Engine", 
                      variable=self.update_engine_var).pack(anchor=tk.W)
        
        # Application updates
        app_frame = ttk.Frame(update_components_frame)
        app_frame.pack(fill=tk.X, pady=5)
        
        self.update_app_var = tk.BooleanVar(value=True)
        ttk.Checkbutton(app_frame, text="Application", 
                      variable=self.update_app_var).pack(anchor=tk.W)
        
        # Save button
        save_update_button = ttk.Button(update_tab, text="Save Update Settings", 
                                      command=self.save_update_settings)
        save_update_button.pack(anchor=tk.W, pady=(10, 0))
        
        # Check for updates button
        check_updates_button = ttk.Button(update_tab, text="Check for Updates Now", 
                                       command=self.check_for_updates)
        check_updates_button.pack(anchor=tk.W, pady=(5, 0))
        
        # Exclusions tab
        exclusions_tab = ttk.Frame(advanced_features_notebook, padding=10)
        advanced_features_notebook.add(exclusions_tab, text="Exclusions")
        
        # File exclusions
        file_exclusions_frame = ttk.LabelFrame(exclusions_tab, text="File Exclusions")
        file_exclusions_frame.pack(fill=tk.BOTH, expand=True, pady=(0, 10))
        
        # Create a listbox with scrollbar
        file_list_frame = ttk.Frame(file_exclusions_frame)
        file_list_frame.pack(fill=tk.BOTH, expand=True, pady=(5, 5))
        
        scrollbar = ttk.Scrollbar(file_list_frame)
        scrollbar.pack(side=tk.RIGHT, fill=tk.Y)
        
        self.file_exclusions_listbox = tk.Listbox(file_list_frame, yscrollcommand=scrollbar.set, 
                                                height=5, selectmode=tk.SINGLE)
        self.file_exclusions_listbox.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
        
        scrollbar.config(command=self.file_exclusions_listbox.yview)
        
        # Populate with default exclusions
        default_file_exclusions = [
            "C:\\Windows\\System32\\config",
            "C:\\Windows\\WinSxS",
            "C:\\Program Files\\Common Files"
        ]
        
        for exclusion in default_file_exclusions:
            self.file_exclusions_listbox.insert(tk.END, exclusion)
        
        # Buttons for managing file exclusions
        file_button_frame = ttk.Frame(file_exclusions_frame)
        file_button_frame.pack(fill=tk.X, pady=(0, 5))
        
        add_file_button = ttk.Button(file_button_frame, text="Add File/Folder", 
                                   command=self.add_file_exclusion)
        add_file_button.pack(side=tk.LEFT, padx=(0, 5))
        
        remove_file_button = ttk.Button(file_button_frame, text="Remove Selected", 
                                      command=self.remove_file_exclusion)
        remove_file_button.pack(side=tk.LEFT)
        
        # Extension exclusions
        extension_exclusions_frame = ttk.LabelFrame(exclusions_tab, text="Extension Exclusions")
        extension_exclusions_frame.pack(fill=tk.BOTH, expand=True, pady=(0, 10))
        
        # Create a listbox with scrollbar
        ext_list_frame = ttk.Frame(extension_exclusions_frame)
        ext_list_frame.pack(fill=tk.BOTH, expand=True, pady=(5, 5))
        
        scrollbar = ttk.Scrollbar(ext_list_frame)
        scrollbar.pack(side=tk.RIGHT, fill=tk.Y)
        
        self.extension_exclusions_listbox = tk.Listbox(ext_list_frame, yscrollcommand=scrollbar.set, 
                                                     height=5, selectmode=tk.SINGLE)
        self.extension_exclusions_listbox.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
        
        scrollbar.config(command=self.extension_exclusions_listbox.yview)
        
        # Populate with default exclusions
        default_extension_exclusions = [
            ".dll", ".exe", ".sys", ".tmp", ".log"
        ]
        
        for exclusion in default_extension_exclusions:
            self.extension_exclusions_listbox.insert(tk.END, exclusion)
        
        # Buttons for managing extension exclusions
        ext_button_frame = ttk.Frame(extension_exclusions_frame)
        ext_button_frame.pack(fill=tk.X, pady=(0, 5))
        
        add_ext_button = ttk.Button(ext_button_frame, text="Add Extension", 
                                  command=self.add_extension_exclusion)
        add_ext_button.pack(side=tk.LEFT, padx=(0, 5))
        
        remove_ext_button = ttk.Button(ext_button_frame, text="Remove Selected", 
                                     command=self.remove_extension_exclusion)
        remove_ext_button.pack(side=tk.LEFT)
        
        # Save button
        save_exclusions_button = ttk.Button(exclusions_tab, text="Save Exclusions", 
                                         command=self.save_exclusions)
        save_exclusions_button.pack(anchor=tk.W, pady=(10, 0))
        
        # Backup & Restore tab
        backup_tab = ttk.Frame(advanced_features_notebook, padding=10)
        advanced_features_notebook.add(backup_tab, text="Backup & Restore")
        
        # Backup settings
        backup_frame = ttk.LabelFrame(backup_tab, text="Backup Settings")
        backup_frame.pack(fill=tk.X, pady=(0, 10))
        
        # Enable automatic backups
        auto_backup_frame = ttk.Frame(backup_frame)
        auto_backup_frame.pack(fill=tk.X, pady=5)
        
        self.auto_backup_var = tk.BooleanVar(value=False)
        ttk.Checkbutton(auto_backup_frame, text="Automatic Backups", 
                      variable=self.auto_backup_var).pack(anchor=tk.W)
        
        # Backup frequency
        backup_freq_frame = ttk.Frame(backup_frame)
        backup_freq_frame.pack(fill=tk.X, pady=5)
        
        ttk.Label(backup_freq_frame, text="Backup Frequency:").pack(side=tk.LEFT, padx=(0, 5))
        
        self.backup_frequency_var = tk.StringVar(value="weekly")
        backup_freq_combo = ttk.Combobox(backup_freq_frame, textvariable=self.backup_frequency_var, 
                                       state="readonly", width=15)
        backup_freq_combo["values"] = ("daily", "weekly", "monthly")
        backup_freq_combo.pack(side=tk.LEFT)
        
        # Backup location
        backup_location_frame = ttk.Frame(backup_frame)
        backup_location_frame.pack(fill=tk.X, pady=5)
        
        ttk.Label(backup_location_frame, text="Backup Location:").pack(side=tk.LEFT, padx=(0, 5))
        
        self.backup_location_var = tk.StringVar(value=os.path.join(os.path.dirname(os.path.abspath(__file__)), "backups"))
        backup_location_entry = ttk.Entry(backup_location_frame, textvariable=self.backup_location_var)
        backup_location_entry.pack(side=tk.LEFT, fill=tk.X, expand=True, padx=(0, 5))
        
        browse_button = ttk.Button(backup_location_frame, text="Browse", 
                                 command=self.browse_backup_location)
        browse_button.pack(side=tk.LEFT)
        
        # Backup items
        backup_items_frame = ttk.LabelFrame(backup_tab, text="Backup Items")
        backup_items_frame.pack(fill=tk.X, pady=(0, 10))
        
        # Settings
        settings_frame = ttk.Frame(backup_items_frame)
        settings_frame.pack(fill=tk.X, pady=5)
        
        self.backup_settings_var = tk.BooleanVar(value=True)
        ttk.Checkbutton(settings_frame, text="Settings", 
                      variable=self.backup_settings_var).pack(anchor=tk.W)
        
        # Safe programs
        safe_programs_frame = ttk.Frame(backup_items_frame)
        safe_programs_frame.pack(fill=tk.X, pady=5)
        
        self.backup_safe_programs_var = tk.BooleanVar(value=True)
        ttk.Checkbutton(safe_programs_frame, text="Safe Programs", 
                      variable=self.backup_safe_programs_var).pack(anchor=tk.W)
        
        # Quarantine
        quarantine_frame = ttk.Frame(backup_items_frame)
        quarantine_frame.pack(fill=tk.X, pady=5)
        
        self.backup_quarantine_var = tk.BooleanVar(value=False)
        ttk.Checkbutton(quarantine_frame, text="Quarantine", 
                      variable=self.backup_quarantine_var).pack(anchor=tk.W)
        
        # Logs
        logs_frame = ttk.Frame(backup_items_frame)
        logs_frame.pack(fill=tk.X, pady=5)
        
        self.backup_logs_var = tk.BooleanVar(value=True)
        ttk.Checkbutton(logs_frame, text="Logs", 
                      variable=self.backup_logs_var).pack(anchor=tk.W)
        
        # Save button
        save_backup_button = ttk.Button(backup_tab, text="Save Backup Settings", 
                                      command=self.save_backup_settings)
        save_backup_button.pack(anchor=tk.W, pady=(10, 0))
        
        # Backup now button
        backup_now_button = ttk.Button(backup_tab, text="Backup Now", 
                                     command=self.backup_now)
        backup_now_button.pack(anchor=tk.W, pady=(5, 0))
        
        # Restore button
        restore_button = ttk.Button(backup_tab, text="Restore from Backup", 
                                  command=self.restore_from_backup)
        restore_button.pack(anchor=tk.W, pady=(5, 0))
    
    def add_safe_program(self):
        """Add a program to the safe programs list"""
        file_path = filedialog.askopenfilename(
            title="Select Program",
            filetypes=[("Executable Files", "*.exe"), ("All Files", "*.*")]
        )
        
        if file_path:
            # Check if already in the list
            if file_path in self.scanner.safe_programs:
                messagebox.showinfo("Information", "This program is already in the safe list.")
                return
            
            # Add to the list and update the UI
            self.scanner.safe_programs.append(file_path)
            self.safe_programs_listbox.insert(tk.END, file_path)
            
            # Save to file
            if self.scanner.save_safe_programs(self.scanner.safe_programs):
                self.status_bar.config(text=f"Added {os.path.basename(file_path)} to safe programs")
            else:
                messagebox.showerror("Error", "Failed to save safe programs list.")
    
    def remove_safe_program(self):
        """Remove a program from the safe programs list"""
        selected = self.safe_programs_listbox.curselection()
        if not selected:
            messagebox.showinfo("Information", "Please select a program to remove.")
            return
        
        # Get the selected program
        index = selected[0]
        program = self.safe_programs_listbox.get(index)
        
        # Remove from the list and update the UI
        self.scanner.safe_programs.remove(program)
        self.safe_programs_listbox.delete(index)
        
        # Save to file
        if self.scanner.save_safe_programs(self.scanner.safe_programs):
            self.status_bar.config(text=f"Removed {os.path.basename(program)} from safe programs")
        else:
            messagebox.showerror("Error", "Failed to save safe programs list.")
    
    def change_admin_password(self):
        """Change the admin password"""
        new_password = self.new_password_var.get()
        
        if not new_password:
            messagebox.showinfo("Information", "Please enter a new password.")
            return
        
        self.admin_password = new_password
        self.new_password_var.set("")
        messagebox.showinfo("Success", "Admin password has been changed.")
    
    def export_logs(self):
        """Export logs to a file"""
        file_path = filedialog.asksaveasfilename(
            title="Export Logs",
            defaultextension=".txt",
            filetypes=[("Text Files", "*.txt"), ("All Files", "*.*")]
        )
        
        if file_path:
            try:
                with open(file_path, "w") as f:
                    f.write("SpeedSFV Antivirus Logs\n")
                    f.write("======================\n\n")
                    f.write(f"Export Date: {time.strftime('%Y-%m-%d %H:%M:%S')}\n\n")
                    f.write("Scan Results:\n")
                    f.write(self.results_text.get(1.0, tk.END))
                
                messagebox.showinfo("Success", "Logs exported successfully.")
            except Exception as e:
                messagebox.showerror("Error", f"Failed to export logs: {str(e)}")
    
    def reset_settings(self):
        """Reset all settings to default"""
        result = messagebox.askquestion(
            "Reset Settings",
            "Are you sure you want to reset all settings to default? This cannot be undone.",
            icon="warning"
        )
        
        if result == "yes":
            # Reset settings
            self.realtime_var.set(True)
            self.startup_var.set(True)
            self.archive_var.set(True)
            self.scan_intensity.set(2)
            self.detection_sensitivity.set(2)
            
            # Clear safe programs
            self.scanner.safe_programs = []
            self.scanner.save_safe_programs([])
            self.safe_programs_listbox.delete(0, tk.END)
            
            messagebox.showinfo("Success", "All settings have been reset to default.")
    
    def restore_quarantined_file(self):
        """Restore a file from quarantine"""
        selected = self.quarantine_listbox.curselection()
        if not selected:
            messagebox.showinfo("Information", "Please select a file to restore.")
            return
        
        # Get the selected file
        index = selected[0]
        file_name = self.quarantine_listbox.get(index)
        
        # Find the file in the quarantine list
        for file in self.quarantine_manager.get_quarantined_files():
            if file["file_name"] == file_name:
                # Restore the file
                if self.quarantine_manager.restore_quarantined_file(file["id"]):
                    self.status_bar.config(text=f"Restored {file_name} from quarantine")
                    self.quarantine_listbox.delete(index)
                else:
                    messagebox.showerror("Error", f"Failed to restore {file_name} from quarantine")
                return
        
        messagebox.showerror("Error", f"Failed to find {file_name} in quarantine")
    
    def delete_quarantined_file(self):
        """Delete a file from quarantine"""
        selected = self.quarantine_listbox.curselection()
        if not selected:
            messagebox.showinfo("Information", "Please select a file to delete.")
            return
        
        # Get the selected file
        index = selected[0]
        file_name = self.quarantine_listbox.get(index)
        
        # Find the file in the quarantine list
        for file in self.quarantine_manager.get_quarantined_files():
            if file["file_name"] == file_name:
                # Delete the file
                if self.quarantine_manager.delete_quarantined_file(file["id"]):
                    self.status_bar.config(text=f"Deleted {file_name} from quarantine")
                    self.quarantine_listbox.delete(index)
                else:
                    messagebox.showerror("Error", f"Failed to delete {file_name} from quarantine")
                return
        
        messagebox.showerror("Error", f"Failed to find {file_name} in quarantine")
    
    def delete_all_quarantined_files(self):
        """Delete all files from quarantine"""
        result = messagebox.askquestion(
            "Delete All Quarantined Files",
            "Are you sure you want to delete all files from quarantine? This cannot be undone.",
            icon="warning"
        )
        
        if result == "yes":
            # Delete all files
            if self.quarantine_manager.delete_all_quarantined_files():
                self.status_bar.config(text="Deleted all files from quarantine")
                self.quarantine_listbox.delete(0, tk.END)
            else:
                messagebox.showerror("Error", "Failed to delete all files from quarantine")
    
    def show_threats_dialog(self, threats):
        """Show a dialog with the detected threats and options to quarantine or ignore"""
        threats_window = tk.Toplevel(self.root)
        threats_window.title("Threats Detected")
        threats_window.geometry("700x500")
        threats_window.resizable(True, True)
        threats_window.transient(self.root)
        threats_window.grab_set()
        
        # Center the window
        threats_window.update_idletasks()
        width = threats_window.winfo_width()
        height = threats_window.winfo_height()
        x = (threats_window.winfo_screenwidth() // 2) - (width // 2)
        y = (threats_window.winfo_screenheight() // 2) - (height // 2)
        threats_window.geometry(f"{width}x{height}+{x}+{y}")
        
        # Apply theme
        if self.dark_mode:
            threats_window.configure(bg='#333333')
        else:
            threats_window.configure(bg='#f0f0f0')
        
        # Create a frame for the content
        frame = ttk.Frame(threats_window, padding=20)
        frame.pack(fill=tk.BOTH, expand=True)
        
        # Create a label for the title
        title_label = ttk.Label(frame, text=f"{len(threats)} Threat(s) Detected", font=("Arial", 12, "bold"))
        title_label.pack(pady=(0, 10))
        
        # Create a frame for the threats
        threats_frame = ttk.Frame(frame)
        threats_frame.pack(fill=tk.BOTH, expand=True, pady=(0, 10))
        
        # Create a treeview for the threats
        columns = ("Path", "Threat Type", "Confidence")
        tree = ttk.Treeview(threats_frame, columns=columns, show="headings")
        
        # Define headings
        tree.heading("Path", text="File Path")
        tree.heading("Threat Type", text="Threat Type")
        tree.heading("Confidence", text="Confidence")
        
        # Define columns
        tree.column("Path", width=350)
        tree.column("Threat Type", width=150)
        tree.column("Confidence", width=100)
        
        # Add a scrollbar
        scrollbar = ttk.Scrollbar(threats_frame, orient=tk.VERTICAL, command=tree.yview)
        tree.configure(yscrollcommand=scrollbar.set)
        scrollbar.pack(side=tk.RIGHT, fill=tk.Y)
        tree.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
        
        # Add the threats to the treeview
        for threat in threats:
            tree.insert("", tk.END, values=(
                threat["path"],
                threat["threat_type"],
                f"{threat['confidence']}%"
            ))
        
        # Create buttons
        button_frame = ttk.Frame(frame)
        button_frame.pack(fill=tk.X)
        
        quarantine_all_button = ttk.Button(button_frame, text="Quarantine All", 
                                         command=lambda: self.quarantine_all_threats(threats, threats_window))
        quarantine_all_button.pack(side=tk.LEFT, padx=(0, 5))
        
        quarantine_selected_button = ttk.Button(button_frame, text="Quarantine Selected", 
                                              command=lambda: self.quarantine_selected_threats(tree, threats, threats_window))
        quarantine_selected_button.pack(side=tk.LEFT, padx=(0, 5))
        
        ignore_button = ttk.Button(button_frame, text="Ignore All", command=threats_window.destroy)
        ignore_button.pack(side=tk.RIGHT)
    
    def quarantine_all_threats(self, threats, window):
        """Quarantine all threats"""
        for threat in threats:
            self.quarantine_manager.quarantine_file(
                threat["path"],
                threat["threat_type"],
                threat["confidence"]
            )
            
            # Update the results
            self.update_results(f"Quarantined: {threat['path']} - {threat['threat_type']}\n")
        
        messagebox.showinfo("Quarantine", f"{len(threats)} file(s) moved to quarantine", parent=window)
        window.destroy()
    
    def quarantine_selected_threats(self, tree, threats, window):
        """Quarantine selected threats"""
        selected = tree.selection()
        if not selected:
            messagebox.showinfo("Information", "Please select at least one threat to quarantine", parent=window)
            return
        
        # Get the selected threats
        for item in selected:
            values = tree.item(item, "values")
            path = values[0]
            
            # Find the threat in the list
            for threat in threats:
                if threat["path"] == path:
                    self.quarantine_manager.quarantine_file(
                        threat["path"],
                        threat["threat_type"],
                        threat["confidence"]
                    )
                    
                    # Update the results
                    self.update_results(f"Quarantined: {threat['path']} - {threat['threat_type']}\n")
        
        messagebox.showinfo("Quarantine", f"{len(selected)} file(s) moved to quarantine", parent=window)
        window.destroy()

    def save_schedule_settings(self):
        """Save the schedule settings"""
        # Save the schedule settings
        schedule_settings = {
            "enable_scheduled_scans": self.enable_scheduled_scans_var.get(),
            "schedule_frequency": self.schedule_frequency_var.get(),
            "schedule_hour": self.schedule_hour_var.get(),
            "schedule_minute": self.schedule_minute_var.get(),
            "schedule_scan_type": self.schedule_scan_type_var.get()
        }
        
        # Save to file
        schedule_file = os.path.join(os.path.dirname(os.path.abspath(__file__)), "schedule_settings.json")
        try:
            with open(schedule_file, "w") as f:
                json.dump(schedule_settings, f, indent=4)
            messagebox.showinfo("Success", "Schedule settings saved successfully.")
        except Exception as e:
            messagebox.showerror("Error", f"Failed to save schedule settings: {str(e)}")

    def save_network_settings(self):
        """Save the network settings"""
        # Save the network settings
        network_settings = {
            "enable_network_protection": self.enable_network_protection_var.get(),
            "block_suspicious_connections": self.block_suspicious_connections_var.get(),
            "block_unknown_programs": self.block_unknown_programs_var.get()
        }
        
        # Save to file
        network_file = os.path.join(os.path.dirname(os.path.abspath(__file__)), "network_settings.json")
        try:
            with open(network_file, "w") as f:
                json.dump(network_settings, f, indent=4)
            messagebox.showinfo("Success", "Network settings saved successfully.")
        except Exception as e:
            messagebox.showerror("Error", f"Failed to save network settings: {str(e)}")

    def save_realtime_settings(self):
        """Save the real-time protection settings"""
        # Save the real-time protection settings
        realtime_settings = {
            "enable_realtime_protection": self.enable_realtime_protection_var.get(),
            "scan_new_files": self.scan_new_files_var.get(),
            "scan_downloads": self.scan_downloads_var.get(),
            "scan_usb": self.scan_usb_var.get()
        }
        
        # Save to file
        realtime_file = os.path.join(os.path.dirname(os.path.abspath(__file__)), "realtime_settings.json")
        try:
            with open(realtime_file, "w") as f:
                json.dump(realtime_settings, f, indent=4)
            messagebox.showinfo("Success", "Real-time protection settings saved successfully.")
        except Exception as e:
            messagebox.showerror("Error", f"Failed to save real-time protection settings: {str(e)}")

    def save_privacy_settings(self):
        """Save the privacy settings"""
        # Save the privacy settings
        privacy_settings = {
            "enable_privacy_protection": self.enable_privacy_protection_var.get(),
            "block_webcam": self.block_webcam_var.get(),
            "block_microphone": self.block_mic_var.get(),
            "block_keyloggers": self.block_keyloggers_var.get()
        }
        
        # Save to file
        privacy_file = os.path.join(os.path.dirname(os.path.abspath(__file__)), "privacy_settings.json")
        try:
            with open(privacy_file, "w") as f:
                json.dump(privacy_settings, f, indent=4)
            messagebox.showinfo("Success", "Privacy settings saved successfully.")
        except Exception as e:
            messagebox.showerror("Error", f"Failed to save privacy settings: {str(e)}")

    def save_web_settings(self):
        """Save the web settings"""
        # Save the web settings
        web_settings = {
            "enable_web_protection": self.enable_web_protection_var.get(),
            "block_malicious_sites": self.block_malicious_sites_var.get(),
            "block_phishing": self.block_phishing_var.get(),
            "block_tracking": self.block_tracking_var.get()
        }
        
        # Save to file
        web_file = os.path.join(os.path.dirname(os.path.abspath(__file__)), "web_settings.json")
        try:
            with open(web_file, "w") as f:
                json.dump(web_settings, f, indent=4)
            messagebox.showinfo("Success", "Web settings saved successfully.")
        except Exception as e:
            messagebox.showerror("Error", f"Failed to save web settings: {str(e)}")

    def save_optimization_settings(self):
        """Save the optimization settings"""
        # Save the optimization settings
        optimization_settings = {
            "enable_optimization": self.enable_optimization_var.get(),
            "clean_temp_files": self.clean_temp_files_var.get(),
            "defragment_disk": self.defragment_disk_var.get(),
            "optimize_startup": self.optimize_startup_var.get(),
            "schedule_optimization": self.schedule_optimization_var.get()
        }
        
        # Save to file
        optimization_file = os.path.join(os.path.dirname(os.path.abspath(__file__)), "optimization_settings.json")
        try:
            with open(optimization_file, "w") as f:
                json.dump(optimization_settings, f, indent=4)
            messagebox.showinfo("Success", "Optimization settings saved successfully.")
        except Exception as e:
            messagebox.showerror("Error", f"Failed to save optimization settings: {str(e)}")

    def save_reports_settings(self):
        """Save the reports settings"""
        # Save the reports settings
        reports_settings = {
            "generate_reports": self.generate_reports_var.get(),
            "email_reports": self.email_reports_var.get(),
            "email_address": self.email_address_var.get(),
            "scan_reports": self.scan_reports_var.get(),
            "threat_reports": self.threat_reports_var.get(),
            "system_reports": self.system_reports_var.get()
        }
        
        # Save to file
        reports_file = os.path.join(os.path.dirname(os.path.abspath(__file__)), "reports_settings.json")
        try:
            with open(reports_file, "w") as f:
                json.dump(reports_settings, f, indent=4)
            messagebox.showinfo("Success", "Reports settings saved successfully.")
        except Exception as e:
            messagebox.showerror("Error", f"Failed to save reports settings: {str(e)}")

    def save_update_settings(self):
        """Save the update settings"""
        # Save the update settings
        update_settings = {
            "auto_update": self.auto_update_var.get(),
            "update_frequency": self.update_frequency_var.get(),
            "update_virus_def": self.update_virus_def_var.get(),
            "update_engine": self.update_engine_var.get(),
            "update_app": self.update_app_var.get()
        }
        
        # Save to file
        update_file = os.path.join(os.path.dirname(os.path.abspath(__file__)), "update_settings.json")
        try:
            with open(update_file, "w") as f:
                json.dump(update_settings, f, indent=4)
            messagebox.showinfo("Success", "Update settings saved successfully.")
        except Exception as e:
            messagebox.showerror("Error", f"Failed to save update settings: {str(e)}")

    def generate_report(self):
        """Generate a report"""
        # Generate a report
        report = ""
        report += "Scan Results:\n"
        report += self.results_text.get(1.0, tk.END)
        
        # Save the report to a file
        file_path = filedialog.asksaveasfilename(
            title="Save Report",
            defaultextension=".txt",
            filetypes=[("Text Files", "*.txt"), ("All Files", "*.*")]
        )
        
        if file_path:
            try:
                with open(file_path, "w") as f:
                    f.write(report)
                messagebox.showinfo("Success", "Report saved successfully.")
            except Exception as e:
                messagebox.showerror("Error", f"Failed to save report: {str(e)}")

    def check_for_updates(self):
        """Check for updates"""
        # Check for updates
        messagebox.showinfo("Success", "No updates available.")

    def run_optimization(self):
        """Run optimization"""
        # Run optimization tasks
        if self.clean_temp_files_var.get():
            # Clean temporary files
            temp_files = []
            for root, _, files in os.walk(os.path.join(os.environ.get("USERPROFILE", "C:\\Users\\User"), "AppData\\Local\\Temp")):
                for file in files:
                    temp_files.append(os.path.join(root, file))
            for file in temp_files:
                try:
                    os.remove(file)
                except Exception as e:
                    print(f"Error deleting file: {file} - {str(e)}")
        
        if self.defragment_disk_var.get():
            # Defragment disk
            # This is a complex task and may require additional libraries or system calls
            # For simplicity, this example just prints a message
            print("Defragmenting disk...")
        
        if self.optimize_startup_var.get():
            # Optimize startup
            # This is a complex task and may require additional libraries or system calls
            # For simplicity, this example just prints a message
            print("Optimizing startup...")
        
        messagebox.showinfo("Success", "Optimization tasks completed.")

    def add_file_exclusion(self):
        """Add a file or folder to exclusions"""
        file_path = filedialog.askdirectory(title="Select Directory to Exclude")
        if not file_path:
            file_path = filedialog.askopenfilename(title="Select File to Exclude")
        
        if file_path:
            # Check if already in list
            items = self.file_exclusions_listbox.get(0, tk.END)
            if file_path not in items:
                self.file_exclusions_listbox.insert(tk.END, file_path)
                self.status_bar.config(text=f"Added {file_path} to exclusions")
            else:
                messagebox.showinfo("Information", f"{file_path} is already in exclusions.")
    
    def remove_file_exclusion(self):
        """Remove a file or folder from exclusions"""
        selected = self.file_exclusions_listbox.curselection()
        if not selected:
            messagebox.showinfo("Information", "Please select an item to remove.")
            return
        
        # Get the selected item
        index = selected[0]
        item = self.file_exclusions_listbox.get(index)
        
        # Remove from listbox
        self.file_exclusions_listbox.delete(index)
        self.status_bar.config(text=f"Removed {item} from exclusions")
    
    def add_extension_exclusion(self):
        """Add a file extension to exclusions"""
        extension = simpledialog.askstring("Add Extension", "Enter file extension (e.g. .txt):")
        if extension:
            # Ensure it starts with a dot
            if not extension.startswith("."):
                extension = "." + extension
            
            # Check if already in list
            items = self.extension_exclusions_listbox.get(0, tk.END)
            if extension not in items:
                self.extension_exclusions_listbox.insert(tk.END, extension)
                self.status_bar.config(text=f"Added {extension} to exclusions")
            else:
                messagebox.showinfo("Information", f"{extension} is already in exclusions.")
    
    def remove_extension_exclusion(self):
        """Remove a file extension from exclusions"""
        selected = self.extension_exclusions_listbox.curselection()
        if not selected:
            messagebox.showinfo("Information", "Please select an extension to remove.")
            return
        
        # Get the selected item
        index = selected[0]
        item = self.extension_exclusions_listbox.get(index)
        
        # Remove from listbox
        self.extension_exclusions_listbox.delete(index)
        self.status_bar.config(text=f"Removed {item} from exclusions")
    
    def save_exclusions(self):
        """Save the exclusions"""
        # Get all file exclusions
        file_exclusions = list(self.file_exclusions_listbox.get(0, tk.END))
        
        # Get all extension exclusions
        extension_exclusions = list(self.extension_exclusions_listbox.get(0, tk.END))
        
        # Save to file
        exclusions = {
            "file_exclusions": file_exclusions,
            "extension_exclusions": extension_exclusions
        }
        
        exclusions_file = os.path.join(os.path.dirname(os.path.abspath(__file__)), "exclusions.json")
        try:
            with open(exclusions_file, "w") as f:
                json.dump(exclusions, f, indent=4)
            messagebox.showinfo("Success", "Exclusions saved successfully.")
        except Exception as e:
            messagebox.showerror("Error", f"Failed to save exclusions: {str(e)}")
    
    def browse_backup_location(self):
        """Browse for backup location"""
        directory = filedialog.askdirectory(title="Select Backup Directory")
        if directory:
            self.backup_location_var.set(directory)
    
    def save_backup_settings(self):
        """Save the backup settings"""
        # Save the backup settings
        backup_settings = {
            "auto_backup": self.auto_backup_var.get(),
            "backup_frequency": self.backup_frequency_var.get(),
            "backup_location": self.backup_location_var.get(),
            "backup_settings": self.backup_settings_var.get(),
            "backup_safe_programs": self.backup_safe_programs_var.get(),
            "backup_quarantine": self.backup_quarantine_var.get(),
            "backup_logs": self.backup_logs_var.get()
        }
        
        # Save to file
        backup_file = os.path.join(os.path.dirname(os.path.abspath(__file__)), "backup_settings.json")
        try:
            with open(backup_file, "w") as f:
                json.dump(backup_settings, f, indent=4)
            messagebox.showinfo("Success", "Backup settings saved successfully.")
        except Exception as e:
            messagebox.showerror("Error", f"Failed to save backup settings: {str(e)}")

    def backup_now(self):
        """Perform a backup now"""
        # Get backup location
        backup_location = self.backup_location_var.get()
        
        # Create backup directory if it doesn't exist
        if not os.path.exists(backup_location):
            try:
                os.makedirs(backup_location)
            except Exception as e:
                messagebox.showerror("Error", f"Failed to create backup directory: {str(e)}")
                return
        
        # Create a timestamp for the backup
        timestamp = datetime.datetime.now().strftime("%Y%m%d_%H%M%S")
        backup_dir = os.path.join(backup_location, f"backup_{timestamp}")
        
        try:
            os.makedirs(backup_dir)
        except Exception as e:
            messagebox.showerror("Error", f"Failed to create backup directory: {str(e)}")
            return
        
        # Backup settings
        if self.backup_settings_var.get():
            settings_dir = os.path.join(backup_dir, "settings")
            os.makedirs(settings_dir)
            
            # Copy all JSON files
            for file in os.listdir(os.path.dirname(os.path.abspath(__file__))):
                if file.endswith(".json"):
                    try:
                        shutil.copy2(
                            os.path.join(os.path.dirname(os.path.abspath(__file__)), file),
                            os.path.join(settings_dir, file)
                        )
                    except Exception as e:
                        print(f"Error backing up {file}: {str(e)}")
        
        # Backup safe programs
        if self.backup_safe_programs_var.get():
            try:
                shutil.copy2(
                    os.path.join(os.path.dirname(os.path.abspath(__file__)), "safe_programs.txt"),
                    os.path.join(backup_dir, "safe_programs.txt")
                )
            except Exception as e:
                print(f"Error backing up safe programs: {str(e)}")
        
        # Backup quarantine
        if self.backup_quarantine_var.get():
            quarantine_dir = os.path.join(backup_dir, "quarantine")
            try:
                shutil.copytree(
                    os.path.join(os.path.dirname(os.path.abspath(__file__)), "quarantine"),
                    quarantine_dir
                )
            except Exception as e:
                print(f"Error backing up quarantine: {str(e)}")
        
        # Backup logs
        if self.backup_logs_var.get():
            logs_dir = os.path.join(backup_dir, "logs")
            os.makedirs(logs_dir)
            
            # Copy log files
            for file in os.listdir(os.path.dirname(os.path.abspath(__file__))):
                if file.endswith(".log"):
                    try:
                        shutil.copy2(
                            os.path.join(os.path.dirname(os.path.abspath(__file__)), file),
                            os.path.join(logs_dir, file)
                        )
                    except Exception as e:
                        print(f"Error backing up {file}: {str(e)}")
        
        messagebox.showinfo("Success", f"Backup completed successfully to {backup_dir}")
    
    def restore_from_backup(self):
        """Restore from a backup"""
        # Ask user to select a backup directory
        backup_dir = filedialog.askdirectory(
            title="Select Backup Directory",
            initialdir=self.backup_location_var.get()
        )
        
        if not backup_dir:
            return
        
        # Confirm restore
        result = messagebox.askquestion(
            "Restore from Backup",
            "Are you sure you want to restore from this backup? This will overwrite your current settings.",
            icon="warning"
        )
        
        if result != "yes":
            return
        
        # Restore settings
        settings_dir = os.path.join(backup_dir, "settings")
        if os.path.exists(settings_dir):
            for file in os.listdir(settings_dir):
                if file.endswith(".json"):
                    try:
                        shutil.copy2(
                            os.path.join(settings_dir, file),
                            os.path.join(os.path.dirname(os.path.abspath(__file__)), file)
                        )
                    except Exception as e:
                        print(f"Error restoring {file}: {str(e)}")
        
        # Restore safe programs
        safe_programs_file = os.path.join(backup_dir, "safe_programs.txt")
        if os.path.exists(safe_programs_file):
            try:
                shutil.copy2(
                    safe_programs_file,
                    os.path.join(os.path.dirname(os.path.abspath(__file__)), "safe_programs.txt")
                )
            except Exception as e:
                print(f"Error restoring safe programs: {str(e)}")
        
        # Restore quarantine
        quarantine_dir = os.path.join(backup_dir, "quarantine")
        if os.path.exists(quarantine_dir):
            try:
                # Remove existing quarantine directory
                shutil.rmtree(os.path.join(os.path.dirname(os.path.abspath(__file__)), "quarantine"))
                
                # Copy from backup
                shutil.copytree(
                    quarantine_dir,
                    os.path.join(os.path.dirname(os.path.abspath(__file__)), "quarantine")
                )
            except Exception as e:
                print(f"Error restoring quarantine: {str(e)}")
        
        # Restore logs
        logs_dir = os.path.join(backup_dir, "logs")
        if os.path.exists(logs_dir):
            for file in os.listdir(logs_dir):
                if file.endswith(".log"):
                    try:
                        shutil.copy2(
                            os.path.join(logs_dir, file),
                            os.path.join(os.path.dirname(os.path.abspath(__file__)), file)
                        )
                    except Exception as e:
                        print(f"Error restoring {file}: {str(e)}")
        
        messagebox.showinfo("Success", "Restore completed successfully. Please restart the application for all changes to take effect.")

def main():
    root = tk.Tk()
    app = SpeedSFVApp(root)
    root.mainloop()

if __name__ == "__main__":
    main()
