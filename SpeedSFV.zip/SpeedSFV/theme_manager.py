from PyQt6.QtGui import QPalette, QColor
from PyQt6.QtCore import Qt

class ThemeManager:
    def __init__(self):
        self.current_theme = "dark"
    
    def apply_light_theme(self, app):
        """Apply light theme to the application"""
        palette = QPalette()
        
        # Set base colors
        palette.setColor(QPalette.ColorRole.Window, QColor(240, 240, 240))
        palette.setColor(QPalette.ColorRole.WindowText, QColor(0, 0, 0))
        palette.setColor(QPalette.ColorRole.Base, QColor(255, 255, 255))
        palette.setColor(QPalette.ColorRole.AlternateBase, QColor(245, 245, 245))
        palette.setColor(QPalette.ColorRole.ToolTipBase, QColor(255, 255, 255))
        palette.setColor(QPalette.ColorRole.ToolTipText, QColor(0, 0, 0))
        palette.setColor(QPalette.ColorRole.Text, QColor(0, 0, 0))
        palette.setColor(QPalette.ColorRole.Button, QColor(240, 240, 240))
        palette.setColor(QPalette.ColorRole.ButtonText, QColor(0, 0, 0))
        palette.setColor(QPalette.ColorRole.BrightText, QColor(0, 0, 255))
        
        # Set highlight colors
        palette.setColor(QPalette.ColorRole.Highlight, QColor(42, 130, 218))
        palette.setColor(QPalette.ColorRole.HighlightedText, QColor(255, 255, 255))
        
        # Set disabled colors
        palette.setColor(QPalette.ColorGroup.Disabled, QPalette.ColorRole.WindowText, QColor(120, 120, 120))
        palette.setColor(QPalette.ColorGroup.Disabled, QPalette.ColorRole.Text, QColor(120, 120, 120))
        palette.setColor(QPalette.ColorGroup.Disabled, QPalette.ColorRole.ButtonText, QColor(120, 120, 120))
        
        app.setPalette(palette)
        self.current_theme = "light"
    
    def apply_dark_theme(self, app):
        """Apply dark theme to the application"""
        palette = QPalette()
        
        # Set base colors
        palette.setColor(QPalette.ColorRole.Window, QColor(53, 53, 53))
        palette.setColor(QPalette.ColorRole.WindowText, QColor(255, 255, 255))
        palette.setColor(QPalette.ColorRole.Base, QColor(35, 35, 35))
        palette.setColor(QPalette.ColorRole.AlternateBase, QColor(45, 45, 45))
        palette.setColor(QPalette.ColorRole.ToolTipBase, QColor(53, 53, 53))
        palette.setColor(QPalette.ColorRole.ToolTipText, QColor(255, 255, 255))
        palette.setColor(QPalette.ColorRole.Text, QColor(255, 255, 255))
        palette.setColor(QPalette.ColorRole.Button, QColor(53, 53, 53))
        palette.setColor(QPalette.ColorRole.ButtonText, QColor(255, 255, 255))
        palette.setColor(QPalette.ColorRole.BrightText, QColor(0, 128, 255))
        
        # Set highlight colors
        palette.setColor(QPalette.ColorRole.Highlight, QColor(42, 130, 218))
        palette.setColor(QPalette.ColorRole.HighlightedText, QColor(255, 255, 255))
        
        # Set disabled colors
        palette.setColor(QPalette.ColorGroup.Disabled, QPalette.ColorRole.WindowText, QColor(150, 150, 150))
        palette.setColor(QPalette.ColorGroup.Disabled, QPalette.ColorRole.Text, QColor(150, 150, 150))
        palette.setColor(QPalette.ColorGroup.Disabled, QPalette.ColorRole.ButtonText, QColor(150, 150, 150))
        
        app.setPalette(palette)
        self.current_theme = "dark"
    
    def apply_night_theme(self, app):
        """Apply night theme (dark blue) to the application"""
        palette = QPalette()
        
        # Set base colors - dark blue theme
        palette.setColor(QPalette.ColorRole.Window, QColor(25, 35, 45))
        palette.setColor(QPalette.ColorRole.WindowText, QColor(220, 230, 255))
        palette.setColor(QPalette.ColorRole.Base, QColor(15, 25, 35))
        palette.setColor(QPalette.ColorRole.AlternateBase, QColor(20, 30, 40))
        palette.setColor(QPalette.ColorRole.ToolTipBase, QColor(25, 35, 45))
        palette.setColor(QPalette.ColorRole.ToolTipText, QColor(220, 230, 255))
        palette.setColor(QPalette.ColorRole.Text, QColor(220, 230, 255))
        palette.setColor(QPalette.ColorRole.Button, QColor(25, 35, 45))
        palette.setColor(QPalette.ColorRole.ButtonText, QColor(220, 230, 255))
        palette.setColor(QPalette.ColorRole.BrightText, QColor(100, 180, 255))
        
        # Set highlight colors
        palette.setColor(QPalette.ColorRole.Highlight, QColor(30, 120, 200))
        palette.setColor(QPalette.ColorRole.HighlightedText, QColor(220, 230, 255))
        
        # Set disabled colors
        palette.setColor(QPalette.ColorGroup.Disabled, QPalette.ColorRole.WindowText, QColor(140, 150, 170))
        palette.setColor(QPalette.ColorGroup.Disabled, QPalette.ColorRole.Text, QColor(140, 150, 170))
        palette.setColor(QPalette.ColorGroup.Disabled, QPalette.ColorRole.ButtonText, QColor(140, 150, 170))
        
        app.setPalette(palette)
        self.current_theme = "night"
