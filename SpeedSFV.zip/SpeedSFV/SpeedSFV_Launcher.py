import os
import sys
import subprocess
import tkinter as tk
from tkinter import messagebox, ttk
import threading
import time

def check_python_installed():
    """Check if Python is installed and in PATH"""
    try:
        subprocess.run(["python", "--version"], check=True, capture_output=True)
        return True
    except (subprocess.SubprocessError, FileNotFoundError):
        return False

def check_dependencies_installed():
    """Check if required packages are installed"""
    try:
        # Only check for PyQt6 since it's the main dependency
        import PyQt6
        return True
    except ImportError:
        return False

def install_dependencies_thread(progress_var, status_var, window):
    """Install required dependencies in a separate thread"""
    try:
        # Update status
        status_var.set("Installing PyQt6...")
        progress_var.set(10)
        window.update()
        
        # Install PyQt6 first
        subprocess.run([sys.executable, "-m", "pip", "install", "PyQt6==6.6.1"], 
                      check=True, capture_output=True)
        
        progress_var.set(50)
        status_var.set("Installing psutil...")
        window.update()
        
        # Install psutil
        subprocess.run([sys.executable, "-m", "pip", "install", "psutil==5.9.6"], 
                      check=True, capture_output=True)
        
        progress_var.set(80)
        status_var.set("Installing requests...")
        window.update()
        
        # Install requests
        subprocess.run([sys.executable, "-m", "pip", "install", "requests==2.31.0"], 
                      check=True, capture_output=True)
        
        progress_var.set(100)
        status_var.set("Installation complete!")
        window.update()
        
        # Wait a moment before closing
        time.sleep(1)
        
        # Close the window and launch the application
        window.quit()
        launch_application()
        
    except Exception as e:
        status_var.set(f"Error: {str(e)}")
        messagebox.showerror("Installation Error", 
                           f"Failed to install dependencies: {str(e)}\n\n"
                           "Please try running 'pip install -r requirements.txt' manually.")
        window.quit()

def install_dependencies_with_progress():
    """Install dependencies with a progress bar"""
    # Create a window for the progress bar
    window = tk.Tk()
    window.title("Installing SpeedSFV Dependencies")
    window.geometry("400x150")
    window.resizable(False, False)
    
    # Center the window
    window.update_idletasks()
    width = window.winfo_width()
    height = window.winfo_height()
    x = (window.winfo_screenwidth() // 2) - (width // 2)
    y = (window.winfo_screenheight() // 2) - (height // 2)
    window.geometry(f"{width}x{height}+{x}+{y}")
    
    # Create a frame for the content
    frame = tk.Frame(window, padx=20, pady=20)
    frame.pack(fill=tk.BOTH, expand=True)
    
    # Create a label for the title
    title_label = tk.Label(frame, text="Installing SpeedSFV Dependencies", font=("Arial", 12, "bold"))
    title_label.pack(pady=(0, 10))
    
    # Create a progress bar
    progress_var = tk.IntVar()
    progress_bar = ttk.Progressbar(frame, variable=progress_var, length=350, mode="determinate")
    progress_bar.pack(pady=(0, 10))
    
    # Create a label for the status
    status_var = tk.StringVar()
    status_var.set("Preparing installation...")
    status_label = tk.Label(frame, textvariable=status_var)
    status_label.pack()
    
    # Start the installation in a separate thread
    install_thread = threading.Thread(
        target=install_dependencies_thread, 
        args=(progress_var, status_var, window)
    )
    install_thread.daemon = True
    install_thread.start()
    
    # Start the main loop
    window.mainloop()
    
    # Return True if the progress reached 100%
    return progress_var.get() == 100

def launch_application():
    """Launch the main application"""
    try:
        # Use subprocess.Popen to start the application without waiting for it to finish
        subprocess.Popen([sys.executable, "main.py"], 
                        cwd=os.path.dirname(os.path.abspath(__file__)))
        return True
    except Exception as e:
        messagebox.showerror("Error", f"Failed to launch SpeedSFV: {str(e)}")
        return False

def main():
    # Create a hidden root window
    root = tk.Tk()
    root.withdraw()
    
    # Check if Python is installed
    if not check_python_installed():
        messagebox.showerror("Error", "Python is not installed or not in PATH.\n"
                           "Please install Python from https://www.python.org/downloads/")
        return
    
    # Check if dependencies are installed
    if not check_dependencies_installed():
        result = messagebox.askquestion("Dependencies Missing", 
                                      "Required packages are not installed.\n"
                                      "Would you like to install them now?")
        if result == "yes":
            if not install_dependencies_with_progress():
                return
        else:
            return
    else:
        # Launch the application
        if launch_application():
            # Close the launcher
            root.destroy()

if __name__ == "__main__":
    main()
