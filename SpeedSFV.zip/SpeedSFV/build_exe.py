import os
import sys
import subprocess

def build_executable():
    """Build the SpeedSFV executable using PyInstaller"""
    print("Building SpeedSFV Antivirus executable...")
    
    # Make sure PyInstaller is installed
    try:
        subprocess.run([sys.executable, "-m", "pip", "install", "pyinstaller"], check=True)
    except subprocess.CalledProcessError:
        print("Failed to install PyInstaller. Please install it manually.")
        return False
    
    # Build the executable
    try:
        subprocess.run([
            "pyinstaller",
            "--name=SpeedSFV",
            "--icon=icons/shield.png",
            "--windowed",
            "--onefile",
            "main.py"
        ], check=True)
        
        print("\nBuild successful!")
        print(f"Executable created at: {os.path.abspath('dist/SpeedSFV.exe')}")
        return True
    except subprocess.CalledProcessError:
        print("Failed to build executable. Check the error messages above.")
        return False

if __name__ == "__main__":
    build_executable()
