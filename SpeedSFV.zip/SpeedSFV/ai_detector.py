import os
import time
import random
import hashlib
import re
import json
import math

class AIDetector:
    """
    Simulates an AI-based malware detection system.
    This is a simplified simulation for demonstration purposes.
    """
    
    def __init__(self):
        self.threat_types = {
            0: "Clean",
            1: "Trojan",
            2: "Ransomware",
            3: "Adware",
            4: "Spyware",
            5: "Worm",
            6: "Backdoor",
            7: "Rootkit",
            8: "Keylogger",
            9: "Potentially Unwanted Program (PUP)"
        }
        
        # List of safe vendors - files from these vendors are less likely to be flagged
        self.safe_vendors = [
            "microsoft",
            "google",
            "apple",
            "adobe",
            "intel",
            "amd",
            "nvidia",
            "oracle",
            "ibm",
            "cisco",
            "mozilla",
            "steam",
            "epic games",
            "blizzard",
            "riot games",
            "electronic arts"
        ]
        
        # Load whitelist from file
        self.whitelist = self._load_whitelist()
        
        # Detection sensitivity (1-3)
        # 1: Low (fewer false positives, might miss some threats)
        # 2: Medium (balanced)
        # 3: High (more false positives, catches more threats)
        self.sensitivity = 2
        
        # AI mode
        # "balanced": Default mode
        # "aggressive": More aggressive detection (more false positives)
        # "cautious": More cautious detection (fewer false positives)
        self.ai_mode = "balanced"
        
        # Advanced features
        self.behavioral_analysis_enabled = True
        self.heuristic_detection_enabled = True
        self.cloud_analysis_enabled = True
        
        # Load detection rules
        self.detection_rules = self._load_detection_rules()
    
    def _load_whitelist(self):
        """Load whitelist of safe programs from file"""
        whitelist = []
        whitelist_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), "safe_programs.txt")
        
        if os.path.exists(whitelist_path):
            with open(whitelist_path, "r") as f:
                for line in f:
                    line = line.strip()
                    if line and not line.startswith("#"):
                        whitelist.append(line.lower())
        
        return whitelist
    
    def _load_detection_rules(self):
        """Load detection rules for common malware patterns"""
        return {
            "suspicious_strings": [
                "CreateRemoteThread",
                "VirtualAllocEx",
                "SetWindowsHookEx",
                "GetAsyncKeyState",
                "CreateMutex",
                "WriteProcessMemory",
                "ShellExecute",
                "GetTempPath",
                "DownloadFile",
                "cmd.exe /c",
                "powershell -e",
                "WScript.Shell",
                "RegWrite",
                "AutoIt",
                "netsh firewall",
                "taskkill",
                "net user",
                "net localgroup",
                "net stop",
                "sc stop",
                "reg delete",
                "reg add",
                "attrib +h",
                "schtasks",
                "wevtutil",
                "vssadmin delete",
                "bcdedit",
                "icacls",
                "rundll32",
                "regsvr32",
                "mshta",
                "wmic",
                "bitsadmin",
                "certutil -decode",
                "certutil -urlcache",
                "regsvcs",
                "regasm",
                "installutil",
                "odbcconf",
                "pcalua"
            ],
            "suspicious_file_extensions": [
                ".exe",
                ".dll",
                ".bat",
                ".cmd",
                ".ps1",
                ".vbs",
                ".js",
                ".wsf",
                ".hta",
                ".scr",
                ".pif"
            ],
            "ransomware_extensions": [
                ".locked",
                ".encrypted",
                ".crypted",
                ".crypt",
                ".crypto",
                ".locky",
                ".cerber",
                ".cerber3",
                ".crypt",
                ".cryptolocker",
                ".cryptowall",
                ".crypz",
                ".cryp1",
                ".wncry",
                ".wncryt",
                ".wcry",
                ".wncrypt",
                ".zepto",
                ".thor",
                ".rokku",
                ".enciphered",
                ".aesir",
                ".alcatraz",
                ".bansomqare",
                ".bart",
                ".best",
                ".bleep",
                ".bloc",
                ".btc",
                ".ccc",
                ".chifrator",
                ".coded",
                ".crinf",
                ".crjoker",
                ".crptrgr",
                ".czvxce",
                ".darkness",
                ".dharma",
                ".enc",
                ".enigma",
                ".exotic",
                ".exx",
                ".ezz",
                ".fantom",
                ".good",
                ".grt",
                ".ha3",
                ".herbst",
                ".karma",
                ".key",
                ".lol",
                ".magic",
                ".micro",
                ".mole",
                ".onion",
                ".oops",
                ".osiris",
                ".p5tkjw",
                ".padcrypt",
                ".paym",
                ".pzdc",
                ".r5a",
                ".rdm",
                ".rrk",
                ".sage",
                ".serpent",
                ".sexy",
                ".shit",
                ".spora",
                ".stn",
                ".venusf",
                ".vvv",
                ".wallet",
                ".xort",
                ".xtbl",
                ".xxx",
                ".xyz",
                ".zc",
                ".zcrypt",
                ".zz",
                ".zzz"
            ]
        }
    
    def analyze(self, file_path):
        """
        Analyze a file for potential threats.
        Returns a dict with analysis results.
        """
        # Skip analysis if file is in whitelist
        if self._is_whitelisted(file_path):
            return {
                "is_malicious": False,
                "threat_type": self.threat_types[0],
                "confidence": 0,
                "details": "File is in whitelist"
            }
        
        # Simulate AI processing time
        time.sleep(0.01)
        
        # Get file info
        file_size = os.path.getsize(file_path)
        file_name = os.path.basename(file_path)
        file_ext = os.path.splitext(file_name.lower())[1]
        
        # Check for known safe vendors in filename
        vendor_match = self._check_safe_vendor(file_name)
        
        # Calculate file hash
        file_hash = self._calculate_file_hash(file_path)
        
        # Basic heuristic analysis
        heuristic_score = self._heuristic_analysis(file_path, file_ext, file_size)
        
        # Adjust score based on vendor
        if vendor_match and self.ai_mode != "aggressive":
            heuristic_score *= 0.5  # Reduce score by 50% for known safe vendors
        
        # Adjust score based on sensitivity
        if self.sensitivity == 1:  # Low
            heuristic_score *= 0.7
        elif self.sensitivity == 3:  # High
            heuristic_score *= 1.3
        
        # Adjust score based on AI mode
        if self.ai_mode == "aggressive":
            heuristic_score *= 1.5
        elif self.ai_mode == "cautious":
            heuristic_score *= 0.6
        
        # Determine if file is malicious based on score
        is_malicious = heuristic_score > 70
        
        # If score is borderline (40-70) and from a safe vendor, consider it safe
        if 40 <= heuristic_score <= 70 and vendor_match and self.ai_mode != "aggressive":
            is_malicious = False
        
        # Determine threat type based on analysis
        threat_type_id = 0  # Default to Clean
        if is_malicious:
            # Determine threat type based on file characteristics
            if self._check_ransomware_patterns(file_path, file_ext):
                threat_type_id = 2  # Ransomware
            elif self._check_trojan_patterns(file_path):
                threat_type_id = 1  # Trojan
            elif self._check_adware_patterns(file_path):
                threat_type_id = 3  # Adware
            elif self._check_spyware_patterns(file_path):
                threat_type_id = 4  # Spyware
            elif self._check_worm_patterns(file_path):
                threat_type_id = 5  # Worm
            elif self._check_backdoor_patterns(file_path):
                threat_type_id = 6  # Backdoor
            elif self._check_rootkit_patterns(file_path):
                threat_type_id = 7  # Rootkit
            elif self._check_keylogger_patterns(file_path):
                threat_type_id = 8  # Keylogger
            else:
                threat_type_id = 9  # PUP
        
        # Calculate confidence level (0-100)
        confidence = min(int(heuristic_score), 100)
        
        # Return analysis results
        return {
            "is_malicious": is_malicious,
            "threat_type": self.threat_types[threat_type_id],
            "confidence": confidence,
            "details": f"File analyzed with {confidence}% confidence",
            "file_hash": file_hash,
            "heuristic_score": heuristic_score
        }
    
    def _is_whitelisted(self, file_path):
        """Check if file is in whitelist"""
        file_path_lower = file_path.lower()
        
        for whitelist_item in self.whitelist:
            if whitelist_item in file_path_lower:
                return True
        
        return False
    
    def _check_safe_vendor(self, file_name):
        """Check if file name contains a known safe vendor"""
        file_name_lower = file_name.lower()
        
        for vendor in self.safe_vendors:
            if vendor in file_name_lower:
                return True
        
        return False
    
    def _calculate_file_hash(self, file_path):
        """Calculate SHA-256 hash of file"""
        try:
            sha256_hash = hashlib.sha256()
            with open(file_path, "rb") as f:
                # Read file in chunks to handle large files
                for byte_block in iter(lambda: f.read(4096), b""):
                    sha256_hash.update(byte_block)
            return sha256_hash.hexdigest()
        except:
            return None
    
    def _heuristic_analysis(self, file_path, file_ext, file_size):
        """
        Perform heuristic analysis on file.
        Returns a score from 0-100, where higher values indicate more suspicious files.
        """
        score = 0
        
        # Check file extension
        if file_ext in self.detection_rules["suspicious_file_extensions"]:
            score += 10
        
        # Check file size
        if file_size < 100 * 1024:  # Small files (< 100 KB)
            score += 5
        elif file_size > 50 * 1024 * 1024:  # Large files (> 50 MB)
            score += 3
        
        # Check for suspicious strings in file
        suspicious_strings_count = self._check_suspicious_strings(file_path)
        score += suspicious_strings_count * 5
        
        # Check for obfuscation techniques
        if self._check_obfuscation(file_path):
            score += 15
        
        # Check for encryption
        if self._check_encryption(file_path):
            score += 10
        
        # Check for packing
        if self._check_packing(file_path):
            score += 15
        
        # Check for anti-VM/anti-debug techniques
        if self._check_anti_analysis(file_path):
            score += 20
        
        # Add some randomness to simulate AI variability
        # But reduce the randomness to make detection more consistent
        score += random.randint(-5, 5)
        
        # Ensure score is within 0-100 range
        return max(0, min(score, 100))
    
    def _check_suspicious_strings(self, file_path):
        """Check for suspicious strings in file"""
        try:
            count = 0
            with open(file_path, "rb") as f:
                content = f.read().decode("utf-8", errors="ignore")
                
                for suspicious_string in self.detection_rules["suspicious_strings"]:
                    if suspicious_string in content:
                        count += 1
            
            return min(count, 10)  # Cap at 10 to prevent excessive scoring
        except:
            return 0
    
    def _check_obfuscation(self, file_path):
        """Check for code obfuscation techniques"""
        try:
            with open(file_path, "rb") as f:
                content = f.read().decode("utf-8", errors="ignore")
                
                # Check for excessive use of escape sequences
                if content.count("\\x") > 100 or content.count("\\u") > 100:
                    return True
                
                # Check for excessive base64 content
                base64_pattern = r"[A-Za-z0-9+/]{50,}={0,2}"
                if len(re.findall(base64_pattern, content)) > 3:
                    return True
                
                # Check for excessive hex strings
                hex_pattern = r"0x[0-9A-Fa-f]{10,}"
                if len(re.findall(hex_pattern, content)) > 5:
                    return True
            
            return False
        except:
            return False
    
    def _check_encryption(self, file_path):
        """Check for signs of encryption"""
        try:
            # Calculate entropy of file
            entropy = self._calculate_entropy(file_path)
            
            # High entropy (> 7.0) often indicates encryption or compression
            return entropy > 7.0
        except:
            return False
    
    def _calculate_entropy(self, file_path):
        """Calculate Shannon entropy of file"""
        try:
            with open(file_path, "rb") as f:
                data = f.read(1024 * 1024)  # Read up to 1 MB
                
                if not data:
                    return 0
                
                # Count byte frequency
                byte_count = {}
                for byte in data:
                    byte_count[byte] = byte_count.get(byte, 0) + 1
                
                # Calculate entropy
                entropy = 0
                for count in byte_count.values():
                    probability = count / len(data)
                    entropy -= probability * (math.log(probability) / math.log(2))
                
                return entropy
        except:
            return 0
    
    def _check_packing(self, file_path):
        """Check for signs of packing"""
        # This is a simplified simulation
        return False
    
    def _check_anti_analysis(self, file_path):
        """Check for anti-VM or anti-debugging techniques"""
        try:
            with open(file_path, "rb") as f:
                content = f.read().decode("utf-8", errors="ignore")
                
                anti_analysis_strings = [
                    "IsDebuggerPresent",
                    "CheckRemoteDebuggerPresent",
                    "GetTickCount",
                    "QueryPerformanceCounter",
                    "GetSystemTime",
                    "VirtualBox",
                    "VMware",
                    "QEMU",
                    "Sandboxie",
                    "Wine",
                    "VBoxService",
                    "VBoxTray",
                    "vmtoolsd",
                    "vboxtray",
                    "vboxservice",
                    "vmwaretray",
                    "vmwareservice",
                    "HKEY_LOCAL_MACHINE\\HARDWARE\\DEVICEMAP\\Scsi\\Scsi Port 0\\Scsi Bus 0\\Target Id 0\\Logical Unit Id 0"
                ]
                
                for string in anti_analysis_strings:
                    if string in content:
                        return True
            
            return False
        except:
            return False
    
    def _check_ransomware_patterns(self, file_path, file_ext):
        """Check for ransomware patterns"""
        # Check for ransomware file extensions
        if file_ext in self.detection_rules["ransomware_extensions"]:
            return True
        
        try:
            with open(file_path, "rb") as f:
                content = f.read().decode("utf-8", errors="ignore")
                
                ransomware_strings = [
                    "your files have been encrypted",
                    "your files are locked",
                    "pay the ransom",
                    "bitcoin",
                    "btc",
                    "monero",
                    "xmr",
                    "decrypt",
                    "recovery key",
                    "payment",
                    "deadline",
                    "encrypt",
                    "all your documents",
                    "important files"
                ]
                
                count = 0
                for string in ransomware_strings:
                    if string in content.lower():
                        count += 1
                
                return count >= 3
        except:
            return False
    
    def _check_trojan_patterns(self, file_path):
        """Check for trojan patterns"""
        try:
            with open(file_path, "rb") as f:
                content = f.read().decode("utf-8", errors="ignore")
                
                trojan_strings = [
                    "backdoor",
                    "remote access",
                    "keylog",
                    "steal",
                    "password",
                    "credential",
                    "exfiltrate",
                    "command and control",
                    "c&c",
                    "c2",
                    "beacon"
                ]
                
                count = 0
                for string in trojan_strings:
                    if string in content.lower():
                        count += 1
                
                return count >= 2
        except:
            return False
    
    def _check_adware_patterns(self, file_path):
        """Check for adware patterns"""
        try:
            with open(file_path, "rb") as f:
                content = f.read().decode("utf-8", errors="ignore")
                
                adware_strings = [
                    "advertisement",
                    "popup",
                    "pop-up",
                    "banner",
                    "offer",
                    "coupon",
                    "special offer",
                    "discount",
                    "browser extension",
                    "toolbar",
                    "redirect"
                ]
                
                count = 0
                for string in adware_strings:
                    if string in content.lower():
                        count += 1
                
                return count >= 3
        except:
            return False
    
    def _check_spyware_patterns(self, file_path):
        """Check for spyware patterns"""
        try:
            with open(file_path, "rb") as f:
                content = f.read().decode("utf-8", errors="ignore")
                
                spyware_strings = [
                    "monitor",
                    "tracking",
                    "surveillance",
                    "spy",
                    "keylog",
                    "screenshot",
                    "webcam",
                    "microphone",
                    "record",
                    "browser history",
                    "location"
                ]
                
                count = 0
                for string in spyware_strings:
                    if string in content.lower():
                        count += 1
                
                return count >= 2
        except:
            return False
    
    def _check_worm_patterns(self, file_path):
        """Check for worm patterns"""
        try:
            with open(file_path, "rb") as f:
                content = f.read().decode("utf-8", errors="ignore")
                
                worm_strings = [
                    "propagate",
                    "spread",
                    "replicate",
                    "network",
                    "share",
                    "usb",
                    "removable",
                    "drive",
                    "email",
                    "message",
                    "contact"
                ]
                
                count = 0
                for string in worm_strings:
                    if string in content.lower():
                        count += 1
                
                return count >= 3
        except:
            return False
    
    def _check_backdoor_patterns(self, file_path):
        """Check for backdoor patterns"""
        try:
            with open(file_path, "rb") as f:
                content = f.read().decode("utf-8", errors="ignore")
                
                backdoor_strings = [
                    "backdoor",
                    "remote access",
                    "remote control",
                    "remote shell",
                    "reverse shell",
                    "bind shell",
                    "command",
                    "execute",
                    "socket",
                    "connect",
                    "listen"
                ]
                
                count = 0
                for string in backdoor_strings:
                    if string in content.lower():
                        count += 1
                
                return count >= 2
        except:
            return False
    
    def _check_rootkit_patterns(self, file_path):
        """Check for rootkit patterns"""
        try:
            with open(file_path, "rb") as f:
                content = f.read().decode("utf-8", errors="ignore")
                
                rootkit_strings = [
                    "rootkit",
                    "hook",
                    "intercept",
                    "hide",
                    "hidden",
                    "stealth",
                    "kernel",
                    "driver",
                    "system",
                    "privilege",
                    "escalation"
                ]
                
                count = 0
                for string in rootkit_strings:
                    if string in content.lower():
                        count += 1
                
                return count >= 3
        except:
            return False
    
    def _check_keylogger_patterns(self, file_path):
        """Check for keylogger patterns"""
        try:
            with open(file_path, "rb") as f:
                content = f.read().decode("utf-8", errors="ignore")
                
                keylogger_strings = [
                    "keylog",
                    "keystroke",
                    "keyboard",
                    "hook",
                    "capture",
                    "record",
                    "input",
                    "type",
                    "GetAsyncKeyState",
                    "GetKeyboardState",
                    "GetKeyState"
                ]
                
                count = 0
                for string in keylogger_strings:
                    if string in content.lower():
                        count += 1
                
                return count >= 2
        except:
            return False

# For testing
if __name__ == "__main__":
    detector = AIDetector()
    
    # Test with a sample file
    test_file = __file__  # Use this script as a test file
    result = detector.analyze(test_file)
    
    print(f"File: {test_file}")
    print(f"Is Malicious: {result['is_malicious']}")
    print(f"Threat Type: {result['threat_type']}")
    print(f"Confidence: {result['confidence']}%")
    print(f"Details: {result['details']}")
    print(f"File Hash: {result['file_hash']}")
    print(f"Heuristic Score: {result['heuristic_score']}")
