import os
import sys
import subprocess
import platform

def setup_environment():
    """Set up the development environment for SpeedSFV"""
    print("Setting up SpeedSFV development environment...")
    
    # Install required packages
    print("\nInstalling required packages...")
    try:
        subprocess.run([sys.executable, "-m", "pip", "install", "-r", "requirements.txt"], check=True)
        print("Successfully installed required packages.")
    except subprocess.CalledProcessError:
        print("Failed to install required packages. Please check your internet connection and try again.")
        return False
    
    # Create the shield icon
    print("\nCreating shield icon...")
    try:
        # First install Pillow if not already installed
        subprocess.run([sys.executable, "-m", "pip", "install", "Pillow"], check=True)
        
        # Change directory to icons and run the shield.py script
        os.chdir("icons")
        subprocess.run([sys.executable, "shield.py"], check=True)
        os.chdir("..")
        print("Successfully created shield icon.")
    except subprocess.CalledProcessError:
        print("Failed to create shield icon. The application will still work, but without the icon.")
    
    print("\nSetup completed successfully!")
    print("You can now run the application using 'python main.py' or by executing run_speedsfv.bat")
    return True

if __name__ == "__main__":
    setup_environment()
