import sys
import os
import time
import datetime
import threading
import psutil
from PyQt6.QtWidgets import (QApplication, QMainWindow, QTabWidget, QWidget, QVBoxLayout,
                            QPushButton, QLabel, QProgressBar, QFileDialog, QListWidget,
                            QHBoxLayout, QComboBox, QCheckBox, QMessageBox, QSystemTrayIcon,
                            QMenu, QGridLayout, QFrame, QSpacerItem, QSizePolicy, QScrollArea)
from PyQt6.QtCore import Qt, QTimer, pyqtSignal, QThread, QSize
from PyQt6.QtGui import QIcon, QPixmap, QFont, QAction, QPalette, QColor

from scanner import Scanner
from ai_detector import AIDetector
from utils import get_file_size_str, get_system_info
from theme_manager import ThemeManager

class ScanWorker(QThread):
    progress_updated = pyqtSignal(int)
    file_scanned = pyqtSignal(str)
    scan_completed = pyqtSignal(list)
    
    def __init__(self, scan_type, custom_path=None):
        super().__init__()
        self.scan_type = scan_type
        self.custom_path = custom_path
        self.scanner = Scanner()
        self.ai_detector = AIDetector()
        self.is_running = True
        
    def run(self):
        threats = []
        
        if self.scan_type == "Quick Scan":
            paths = [
                os.path.join(os.environ["SYSTEMROOT"], "System32"),
                os.path.join(os.environ["USERPROFILE"], "Downloads"),
                os.path.join(os.environ["USERPROFILE"], "Desktop"),
                os.path.join(os.environ["APPDATA"])
            ]
            
            # Limit the number of files to scan for quick scan
            max_files = 1000
            files_to_scan = []
            
            for path in paths:
                if not os.path.exists(path):
                    continue
                for root, _, files in os.walk(path):
                    for file in files:
                        full_path = os.path.join(root, file)
                        files_to_scan.append(full_path)
                        if len(files_to_scan) >= max_files:
                            break
                    if len(files_to_scan) >= max_files:
                        break
                if len(files_to_scan) >= max_files:
                    break
            
            total_files = len(files_to_scan)
            
            for i, full_path in enumerate(files_to_scan):
                if not self.is_running:
                    return
                self.file_scanned.emit(full_path)
                
                # Simulate scanning with the scanner and AI detector
                is_threat = self.scanner.scan_file(full_path)
                if is_threat:
                    ai_result = self.ai_detector.analyze(full_path)
                    if ai_result["is_malicious"]:
                        threats.append({
                            "path": full_path,
                            "threat_type": ai_result["threat_type"],
                            "confidence": ai_result["confidence"]
                        })
                
                progress = int(((i + 1) / total_files) * 100)
                self.progress_updated.emit(progress)
                
                # Simulate processing time (reduced for faster scanning)
                time.sleep(0.001)
        
        elif self.scan_type == "Full Scan":
            # For demo purposes, we'll limit the full scan to a sample of files
            drives = [d.device for d in psutil.disk_partitions() if 'fixed' in d.opts]
            
            # Limit the number of files to scan
            max_files = 2000
            files_to_scan = []
            
            for drive in drives:
                for root, _, files in os.walk(drive):
                    for file in files:
                        full_path = os.path.join(root, file)
                        files_to_scan.append(full_path)
                        if len(files_to_scan) >= max_files:
                            break
                    if len(files_to_scan) >= max_files:
                        break
                if len(files_to_scan) >= max_files:
                    break
            
            total_files = len(files_to_scan)
            
            for i, full_path in enumerate(files_to_scan):
                if not self.is_running:
                    return
                self.file_scanned.emit(full_path)
                
                # Simulate scanning with the scanner and AI detector
                is_threat = self.scanner.scan_file(full_path)
                if is_threat:
                    ai_result = self.ai_detector.analyze(full_path)
                    if ai_result["is_malicious"]:
                        threats.append({
                            "path": full_path,
                            "threat_type": ai_result["threat_type"],
                            "confidence": ai_result["confidence"]
                        })
                
                progress = int(((i + 1) / total_files) * 100)
                self.progress_updated.emit(progress)
                
                # Simulate processing time (reduced for faster scanning)
                time.sleep(0.001)
        
        elif self.scan_type == "Custom Scan" and self.custom_path:
            if not os.path.exists(self.custom_path):
                self.scan_completed.emit([])
                return
            
            # Limit the number of files to scan
            max_files = 1500
            files_to_scan = []
            
            for root, _, files in os.walk(self.custom_path):
                for file in files:
                    full_path = os.path.join(root, file)
                    files_to_scan.append(full_path)
                    if len(files_to_scan) >= max_files:
                        break
                if len(files_to_scan) >= max_files:
                    break
            
            total_files = len(files_to_scan)
            
            for i, full_path in enumerate(files_to_scan):
                if not self.is_running:
                    return
                self.file_scanned.emit(full_path)
                
                # Simulate scanning with the scanner and AI detector
                is_threat = self.scanner.scan_file(full_path)
                if is_threat:
                    ai_result = self.ai_detector.analyze(full_path)
                    if ai_result["is_malicious"]:
                        threats.append({
                            "path": full_path,
                            "threat_type": ai_result["threat_type"],
                            "confidence": ai_result["confidence"]
                        })
                
                progress = int(((i + 1) / total_files) * 100)
                self.progress_updated.emit(progress)
                
                # Simulate processing time (reduced for faster scanning)
                time.sleep(0.001)
        
        self.scan_completed.emit(threats)
    
    def stop(self):
        self.is_running = False


class MainWindow(QMainWindow):
    def __init__(self):
        super().__init__()
        
        self.setWindowTitle("SpeedSFV Antivirus")
        self.setMinimumSize(900, 600)
        
        # Initialize theme manager
        self.theme_manager = ThemeManager()
        
        # Create system tray icon
        self.tray_icon = QSystemTrayIcon(self)
        self.tray_icon.setIcon(QIcon("icons/shield.png"))
        
        tray_menu = QMenu()
        open_action = QAction("Open SpeedSFV", self)
        open_action.triggered.connect(self.show)
        quit_action = QAction("Exit", self)
        quit_action.triggered.connect(self.close)
        
        tray_menu.addAction(open_action)
        tray_menu.addAction(quit_action)
        
        self.tray_icon.setContextMenu(tray_menu)
        self.tray_icon.show()
        
        # Create central widget and layout
        central_widget = QWidget()
        self.setCentralWidget(central_widget)
        
        main_layout = QVBoxLayout(central_widget)
        
        # Create header
        header_layout = QHBoxLayout()
        
        logo_label = QLabel()
        # logo_label.setPixmap(QPixmap("icons/logo.png").scaled(64, 64, Qt.AspectRatioMode.KeepAspectRatio))
        
        title_label = QLabel("SpeedSFV Antivirus")
        title_label.setFont(QFont("Arial", 18, QFont.Weight.Bold))
        
        theme_combo = QComboBox()
        theme_combo.addItems(["Light Mode", "Dark Mode", "Night Mode"])
        theme_combo.setCurrentIndex(1)  # Default to Dark Mode
        theme_combo.currentIndexChanged.connect(self.change_theme)
        
        header_layout.addWidget(logo_label)
        header_layout.addWidget(title_label)
        header_layout.addStretch()
        header_layout.addWidget(QLabel("Theme:"))
        header_layout.addWidget(theme_combo)
        
        main_layout.addLayout(header_layout)
        
        # Create tab widget
        self.tabs = QTabWidget()
        
        # Dashboard tab
        dashboard_tab = QWidget()
        dashboard_layout = QVBoxLayout(dashboard_tab)
        
        status_frame = QFrame()
        status_frame.setFrameShape(QFrame.Shape.StyledPanel)
        status_layout = QVBoxLayout(status_frame)
        
        protection_status = QLabel("Protection Status: Active")
        protection_status.setFont(QFont("Arial", 14))
        
        last_scan = QLabel("Last Scan: Never")
        last_scan.setFont(QFont("Arial", 12))
        
        status_layout.addWidget(protection_status)
        status_layout.addWidget(last_scan)
        
        dashboard_layout.addWidget(status_frame)
        
        # Quick actions
        actions_layout = QHBoxLayout()
        
        quick_scan_btn = QPushButton("Quick Scan")
        quick_scan_btn.setMinimumHeight(50)
        quick_scan_btn.clicked.connect(lambda: self.start_scan("Quick Scan"))
        
        full_scan_btn = QPushButton("Full Scan")
        full_scan_btn.setMinimumHeight(50)
        full_scan_btn.clicked.connect(lambda: self.start_scan("Full Scan"))
        
        custom_scan_btn = QPushButton("Custom Scan")
        custom_scan_btn.setMinimumHeight(50)
        custom_scan_btn.clicked.connect(self.select_custom_scan)
        
        actions_layout.addWidget(quick_scan_btn)
        actions_layout.addWidget(full_scan_btn)
        actions_layout.addWidget(custom_scan_btn)
        
        dashboard_layout.addLayout(actions_layout)
        
        # System info
        system_info = get_system_info()
        info_frame = QFrame()
        info_frame.setFrameShape(QFrame.Shape.StyledPanel)
        info_layout = QGridLayout(info_frame)
        
        info_layout.addWidget(QLabel("CPU Usage:"), 0, 0)
        self.cpu_label = QLabel(f"{system_info['cpu_percent']}%")
        info_layout.addWidget(self.cpu_label, 0, 1)
        
        info_layout.addWidget(QLabel("Memory Usage:"), 1, 0)
        self.memory_label = QLabel(f"{system_info['memory_percent']}%")
        info_layout.addWidget(self.memory_label, 1, 1)
        
        info_layout.addWidget(QLabel("Disk Usage:"), 2, 0)
        self.disk_label = QLabel(f"{system_info['disk_percent']}%")
        info_layout.addWidget(self.disk_label, 2, 1)
        
        dashboard_layout.addWidget(info_frame)
        dashboard_layout.addStretch()
        
        # Scanner tab
        scanner_tab = QWidget()
        scanner_layout = QVBoxLayout(scanner_tab)
        
        scan_options_layout = QHBoxLayout()
        
        self.scan_type_combo = QComboBox()
        self.scan_type_combo.addItems(["Quick Scan", "Full Scan", "Custom Scan"])
        
        self.select_path_btn = QPushButton("Select Path")
        self.select_path_btn.setEnabled(False)
        self.select_path_btn.clicked.connect(self.select_custom_scan)
        
        self.scan_type_combo.currentIndexChanged.connect(self.update_scan_options)
        
        scan_options_layout.addWidget(QLabel("Scan Type:"))
        scan_options_layout.addWidget(self.scan_type_combo)
        scan_options_layout.addWidget(self.select_path_btn)
        scan_options_layout.addStretch()
        
        start_scan_btn = QPushButton("Start Scan")
        start_scan_btn.clicked.connect(self.start_scan_from_tab)
        
        scan_options_layout.addWidget(start_scan_btn)
        
        scanner_layout.addLayout(scan_options_layout)
        
        self.scan_progress = QProgressBar()
        self.scan_progress.setValue(0)
        
        self.current_file_label = QLabel("Ready to scan")
        
        scanner_layout.addWidget(self.scan_progress)
        scanner_layout.addWidget(self.current_file_label)
        
        self.scan_results = QListWidget()
        scanner_layout.addWidget(QLabel("Scan Results:"))
        scanner_layout.addWidget(self.scan_results)
        
        # Protection tab
        protection_tab = QWidget()
        protection_layout = QVBoxLayout(protection_tab)
        
        real_time_check = QCheckBox("Real-time Protection")
        real_time_check.setChecked(True)
        
        web_protection_check = QCheckBox("Web Protection")
        web_protection_check.setChecked(True)
        
        ransomware_check = QCheckBox("Ransomware Protection")
        ransomware_check.setChecked(True)
        
        behavior_check = QCheckBox("Behavior Monitoring")
        behavior_check.setChecked(True)
        
        ai_check = QCheckBox("AI-Powered Detection")
        ai_check.setChecked(True)
        
        protection_layout.addWidget(real_time_check)
        protection_layout.addWidget(web_protection_check)
        protection_layout.addWidget(ransomware_check)
        protection_layout.addWidget(behavior_check)
        protection_layout.addWidget(ai_check)
        protection_layout.addStretch()
        
        # Quarantine tab
        quarantine_tab = QWidget()
        quarantine_layout = QVBoxLayout(quarantine_tab)
        
        self.quarantine_list = QListWidget()
        
        quarantine_actions = QHBoxLayout()
        restore_btn = QPushButton("Restore")
        delete_btn = QPushButton("Delete Permanently")
        
        quarantine_actions.addWidget(restore_btn)
        quarantine_actions.addWidget(delete_btn)
        quarantine_actions.addStretch()
        
        quarantine_layout.addWidget(QLabel("Quarantined Items:"))
        quarantine_layout.addWidget(self.quarantine_list)
        quarantine_layout.addLayout(quarantine_actions)
        
        # Settings tab
        settings_tab = QWidget()
        settings_layout = QVBoxLayout(settings_tab)
        
        # Scan settings
        scan_settings_frame = QFrame()
        scan_settings_frame.setFrameShape(QFrame.Shape.StyledPanel)
        scan_settings_layout = QVBoxLayout(scan_settings_frame)
        
        scan_settings_layout.addWidget(QLabel("Scan Settings"))
        
        scan_archives = QCheckBox("Scan Archive Files")
        scan_archives.setChecked(True)
        
        scan_emails = QCheckBox("Scan Email Files")
        scan_emails.setChecked(True)
        
        scan_settings_layout.addWidget(scan_archives)
        scan_settings_layout.addWidget(scan_emails)
        
        settings_layout.addWidget(scan_settings_frame)
        
        # Update settings
        update_settings_frame = QFrame()
        update_settings_frame.setFrameShape(QFrame.Shape.StyledPanel)
        update_settings_layout = QVBoxLayout(update_settings_frame)
        
        update_settings_layout.addWidget(QLabel("Update Settings"))
        
        auto_update = QCheckBox("Automatically Update Virus Definitions")
        auto_update.setChecked(True)
        
        update_frequency = QComboBox()
        update_frequency.addItems(["Daily", "Weekly", "Monthly"])
        
        update_settings_layout.addWidget(auto_update)
        update_settings_layout.addWidget(QLabel("Update Frequency:"))
        update_settings_layout.addWidget(update_frequency)
        
        settings_layout.addWidget(update_settings_frame)
        settings_layout.addStretch()
        
        # Add tabs to tab widget
        self.tabs.addTab(dashboard_tab, "Dashboard")
        self.tabs.addTab(scanner_tab, "Scanner")
        self.tabs.addTab(protection_tab, "Protection")
        self.tabs.addTab(quarantine_tab, "Quarantine")
        self.tabs.addTab(settings_tab, "Settings")
        
        main_layout.addWidget(self.tabs)
        
        # Status bar
        self.statusBar().showMessage("SpeedSFV Antivirus | Ready")
        
        # Set up timer for system info updates
        self.sys_info_timer = QTimer()
        self.sys_info_timer.timeout.connect(self.update_system_info)
        self.sys_info_timer.start(5000)  # Update every 5 seconds
        
        # Initialize scan worker
        self.scan_worker = None
        self.custom_scan_path = None
        
        # Apply default theme (Dark Mode)
        self.change_theme(1)
    
    def change_theme(self, index):
        if index == 0:  # Light Mode
            self.theme_manager.apply_light_theme(self.app)
        elif index == 1:  # Dark Mode
            self.theme_manager.apply_dark_theme(self.app)
        elif index == 2:  # Night Mode
            self.theme_manager.apply_night_theme(self.app)
    
    def update_system_info(self):
        system_info = get_system_info()
        self.cpu_label.setText(f"{system_info['cpu_percent']}%")
        self.memory_label.setText(f"{system_info['memory_percent']}%")
        self.disk_label.setText(f"{system_info['disk_percent']}%")
    
    def update_scan_options(self):
        scan_type = self.scan_type_combo.currentText()
        self.select_path_btn.setEnabled(scan_type == "Custom Scan")
    
    def select_custom_scan(self):
        path = QFileDialog.getExistingDirectory(self, "Select Directory to Scan")
        if path:
            self.custom_scan_path = path
            self.scan_type_combo.setCurrentText("Custom Scan")
            self.statusBar().showMessage(f"Selected path: {path}")
    
    def start_scan_from_tab(self):
        scan_type = self.scan_type_combo.currentText()
        self.start_scan(scan_type)
    
    def start_scan(self, scan_type):
        if self.scan_worker and self.scan_worker.isRunning():
            QMessageBox.warning(self, "Scan in Progress", "A scan is already running. Please wait for it to complete.")
            return
        
        self.scan_results.clear()
        self.scan_progress.setValue(0)
        self.current_file_label.setText("Starting scan...")
        
        if scan_type == "Custom Scan" and not self.custom_scan_path:
            self.select_custom_scan()
            if not self.custom_scan_path:
                return
        
        self.scan_worker = ScanWorker(scan_type, self.custom_scan_path)
        self.scan_worker.progress_updated.connect(self.update_scan_progress)
        self.scan_worker.file_scanned.connect(self.update_current_file)
        self.scan_worker.scan_completed.connect(self.handle_scan_completed)
        
        self.statusBar().showMessage(f"{scan_type} in progress...")
        self.scan_worker.start()
        
        # Switch to scanner tab
        self.tabs.setCurrentIndex(1)
    
    def update_scan_progress(self, value):
        self.scan_progress.setValue(value)
    
    def update_current_file(self, file_path):
        self.current_file_label.setText(f"Scanning: {file_path}")
    
    def handle_scan_completed(self, threats):
        self.current_file_label.setText("Scan completed")
        
        if not threats:
            self.scan_results.addItem("No threats found")
            QMessageBox.information(self, "Scan Completed", "No threats were found during the scan.")
        else:
            for threat in threats:
                self.scan_results.addItem(f"{threat['path']} - {threat['threat_type']} (Confidence: {threat['confidence']}%)")
            
            QMessageBox.warning(
                self, 
                "Threats Detected", 
                f"{len(threats)} threat(s) were found during the scan. See the Scanner tab for details."
            )
            
            # Add to quarantine
            for threat in threats:
                self.quarantine_list.addItem(f"{threat['path']} - {threat['threat_type']}")
        
        self.statusBar().showMessage("Scan completed")
    
    def closeEvent(self, event):
        reply = QMessageBox.question(
            self, 
            "Exit Confirmation",
            "Are you sure you want to exit SpeedSFV Antivirus? Real-time protection will be disabled.",
            QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No,
            QMessageBox.StandardButton.No
        )
        
        if reply == QMessageBox.StandardButton.Yes:
            if self.scan_worker and self.scan_worker.isRunning():
                self.scan_worker.stop()
                self.scan_worker.wait()
            
            self.tray_icon.hide()
            event.accept()
        else:
            event.ignore()


if __name__ == "__main__":
    app = QApplication(sys.argv)
    
    # Create directory for icons if it doesn't exist
    os.makedirs("icons", exist_ok=True)
    
    window = MainWindow()
    window.app = app  # Store reference to app for theme changes
    window.show()
    
    sys.exit(app.exec())
