# SpeedSFV Installation and Setup Guide

This document provides comprehensive instructions for installing and running SpeedSFV Antivirus.

## Prerequisites

- Windows 10 or later
- Python 3.8 or later
- Administrator privileges (for real-time protection features)

## Installation Methods

### Method 1: Simple Installation (No Dependencies)

If you want to quickly try SpeedSFV without installing any dependencies:

1. Double-click on `SimpleSpeedSFV.bat`
2. The application will start using only standard Python libraries

### Method 2: Full Installation

For the complete experience with all features:

1. Install Python from [python.org](https://www.python.org/downloads/) if not already installed
2. Open a command prompt in the SpeedSFV directory
3. Run the setup script:
   ```
   python setup.py
   ```
4. Launch the application using one of these methods:
   - Double-click `SpeedSFV.bat`
   - Double-click `Launch_SpeedSFV.bat`
   - Run `python main.py` in a command prompt

### Method 3: Create Desktop Shortcut

To create a desktop shortcut for easy access:

1. Right-click on `create_desktop_shortcut.bat` and select "Run as administrator"
2. A shortcut will be created on your desktop

## Web Admin Panel

To access the web administration panel:

1. Run `run_web_admin.bat`
2. Open a web browser and navigate to http://localhost:5000
3. Login with the default credentials:
   - Username: admin
   - Password: admin

## Troubleshooting

If you encounter any issues:

1. Ensure Python is properly installed and in your PATH
2. Check that all dependencies are installed by running:
   ```
   pip install -r requirements.txt
   ```
3. If using the full version, make sure PyQt6 is installed:
   ```
   pip install PyQt6
   ```
4. For permission issues, try running the application as administrator

## Updating

SpeedSFV will automatically check for updates. To manually update:

1. Go to the Settings tab
2. Click "Check for Updates"
3. Follow the prompts to install any available updates
