import os
import sys
import json
import time
import shutil
import zipfile
import tempfile
import subprocess
import requests
from datetime import datetime

class Updater:
    def __init__(self, current_version="1.0.0", update_url="https://example.com/speedsfv/updates.json"):
        self.current_version = current_version
        self.update_url = update_url
        self.app_dir = os.path.dirname(os.path.abspath(__file__))
        self.update_dir = os.path.join(self.app_dir, "updates")
        self.version_file = os.path.join(self.app_dir, "version.json")
        self.backup_dir = os.path.join(self.app_dir, "backups")
        
        # Create necessary directories
        os.makedirs(self.update_dir, exist_ok=True)
        os.makedirs(self.backup_dir, exist_ok=True)
        
        # Load or create version file
        if os.path.exists(self.version_file):
            with open(self.version_file, 'r') as f:
                version_data = json.load(f)
                self.current_version = version_data.get('version', current_version)
                self.last_check = version_data.get('last_check', None)
        else:
            self.last_check = None
            self.save_version_info()
    
    def save_version_info(self):
        """Save current version info to file"""
        version_data = {
            'version': self.current_version,
            'last_check': datetime.now().isoformat(),
            'last_update': datetime.now().isoformat() if self.last_check is None else None
        }
        with open(self.version_file, 'w') as f:
            json.dump(version_data, f, indent=4)
    
    def check_for_updates(self):
        """Check if updates are available"""
        try:
            response = requests.get(self.update_url, timeout=10)
            if response.status_code == 200:
                update_data = response.json()
                latest_version = update_data.get('latest_version')
                
                if self._compare_versions(latest_version, self.current_version) > 0:
                    return {
                        'available': True,
                        'current_version': self.current_version,
                        'latest_version': latest_version,
                        'download_url': update_data.get('download_url'),
                        'release_notes': update_data.get('release_notes', '')
                    }
            
            return {'available': False, 'current_version': self.current_version}
        except Exception as e:
            print(f"Error checking for updates: {str(e)}")
            return {'available': False, 'error': str(e)}
    
    def download_update(self, download_url):
        """Download update package"""
        try:
            response = requests.get(download_url, stream=True, timeout=60)
            if response.status_code == 200:
                update_file = os.path.join(self.update_dir, "update.zip")
                with open(update_file, 'wb') as f:
                    for chunk in response.iter_content(chunk_size=8192):
                        f.write(chunk)
                return update_file
            return None
        except Exception as e:
            print(f"Error downloading update: {str(e)}")
            return None
    
    def create_backup(self):
        """Create a backup of the current application"""
        try:
            backup_name = f"backup_{self.current_version}_{datetime.now().strftime('%Y%m%d_%H%M%S')}.zip"
            backup_path = os.path.join(self.backup_dir, backup_name)
            
            with zipfile.ZipFile(backup_path, 'w', zipfile.ZIP_DEFLATED) as zipf:
                for root, _, files in os.walk(self.app_dir):
                    # Skip backup and update directories
                    if root.startswith(self.backup_dir) or root.startswith(self.update_dir):
                        continue
                    
                    for file in files:
                        file_path = os.path.join(root, file)
                        arcname = os.path.relpath(file_path, self.app_dir)
                        zipf.write(file_path, arcname)
            
            return backup_path
        except Exception as e:
            print(f"Error creating backup: {str(e)}")
            return None
    
    def install_update(self, update_file, new_version):
        """Install the downloaded update"""
        try:
            # Create backup first
            backup_path = self.create_backup()
            if not backup_path:
                return False, "Failed to create backup"
            
            # Extract update
            with zipfile.ZipFile(update_file, 'r') as zipf:
                extract_dir = tempfile.mkdtemp()
                zipf.extractall(extract_dir)
            
            # Copy files from update to app directory
            for root, dirs, files in os.walk(extract_dir):
                for file in files:
                    src_path = os.path.join(root, file)
                    rel_path = os.path.relpath(src_path, extract_dir)
                    dst_path = os.path.join(self.app_dir, rel_path)
                    
                    # Create directory if it doesn't exist
                    os.makedirs(os.path.dirname(dst_path), exist_ok=True)
                    
                    # Copy file
                    shutil.copy2(src_path, dst_path)
            
            # Update version
            self.current_version = new_version
            self.save_version_info()
            
            # Clean up
            shutil.rmtree(extract_dir)
            
            return True, "Update installed successfully"
        except Exception as e:
            print(f"Error installing update: {str(e)}")
            return False, f"Error installing update: {str(e)}"
    
    def _compare_versions(self, version1, version2):
        """Compare two version strings"""
        v1_parts = [int(x) for x in version1.split('.')]
        v2_parts = [int(x) for x in version2.split('.')]
        
        for i in range(max(len(v1_parts), len(v2_parts))):
            v1 = v1_parts[i] if i < len(v1_parts) else 0
            v2 = v2_parts[i] if i < len(v2_parts) else 0
            
            if v1 > v2:
                return 1
            elif v1 < v2:
                return -1
        
        return 0
    
    def restore_backup(self, backup_file=None):
        """Restore from a backup file"""
        try:
            if backup_file is None:
                # Find the most recent backup
                backups = [f for f in os.listdir(self.backup_dir) if f.startswith("backup_")]
                if not backups:
                    return False, "No backups found"
                
                backups.sort(reverse=True)
                backup_file = os.path.join(self.backup_dir, backups[0])
            
            # Extract backup
            with zipfile.ZipFile(backup_file, 'r') as zipf:
                zipf.extractall(self.app_dir)
            
            # Reload version info
            if os.path.exists(self.version_file):
                with open(self.version_file, 'r') as f:
                    version_data = json.load(f)
                    self.current_version = version_data.get('version', self.current_version)
            
            return True, f"Restored from backup: {os.path.basename(backup_file)}"
        except Exception as e:
            print(f"Error restoring backup: {str(e)}")
            return False, f"Error restoring backup: {str(e)}"
    
    def restart_application(self):
        """Restart the application"""
        if getattr(sys, 'frozen', False):
            # Running as executable
            subprocess.Popen([sys.executable])
        else:
            # Running as script
            subprocess.Popen([sys.executable] + sys.argv)
        
        sys.exit(0)


# Example usage
if __name__ == "__main__":
    updater = Updater()
    update_info = updater.check_for_updates()
    
    if update_info['available']:
        print(f"Update available: {update_info['latest_version']}")
        print(f"Current version: {update_info['current_version']}")
        print(f"Release notes: {update_info['release_notes']}")
        
        # Download and install update
        update_file = updater.download_update(update_info['download_url'])
        if update_file:
            success, message = updater.install_update(update_file, update_info['latest_version'])
            print(message)
            
            if success:
                print("Restarting application...")
                updater.restart_application()
    else:
        print("No updates available.")
