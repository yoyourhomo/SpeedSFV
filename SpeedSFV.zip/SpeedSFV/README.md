# SpeedSFV Antivirus

SpeedSFV is an advanced antivirus solution that combines the best features of Bitdefender and Malwarebytes with AI-powered detection capabilities.

## Features

- Real-time protection against malware, ransomware, and other threats
- AI-powered code analysis for advanced threat detection
- Multiple scan modes: Quick Scan, Full Scan, Custom Scan
- Dark mode and night mode UI options
- System optimization tools
- Firewall protection
- Scheduled scans
- Quarantine management
- Update system for virus definitions
- Admin panel with advanced configuration options

## Requirements

- Python 3.8+
- Dependencies listed in requirements.txt

## Installation

1. Clone this repository
2. Install the required dependencies:
   ```
   pip install -r requirements.txt
   ```
3. Run the application:
   ```
   python main.py
   ```

## Launch Options

There are several ways to launch SpeedSFV Antivirus:

### Simple Version (Recommended)
The simple version uses only standard Python libraries and doesn't require any additional dependencies:
1. Double-click on `SimpleSpeedSFV.bat`
2. The application will start immediately without installing any dependencies

### Full Version
The full version includes all features and requires PyQt6:
1. Double-click on `SpeedSFV.bat` or `Launch_SpeedSFV.bat`
2. The application will start with the complete UI and all features

### Web Admin Panel
To access the web administration panel:
1. Double-click on `run_web_admin.bat`
2. Open a web browser and navigate to http://localhost:5000
3. Login with the default credentials (username: admin, password: admin)

## Simplified Version

For users who experience issues with dependencies, a simplified version is available:

1. Run the application without dependencies:
   ```
   python SimpleSpeedSFV.py
   ```
   
   Or double-click on `SimpleSpeedSFV.bat`

## Admin Panel

The application includes an admin panel with advanced features:

1. Access the admin panel by clicking the "Admin Panel" button in the top-right corner
2. Default password: `admin123` (you can change this in the admin panel)
3. Admin features include:
   - Managing safe programs list (whitelist)
   - Adjusting scan intensity and detection sensitivity
   - Viewing system information
   - Exporting logs
   - Resetting application settings

## Admin Panel Features

The SpeedSFV Admin Panel provides advanced management capabilities:

### Safe Programs Management
- Add trusted programs to the safe list
- Remove programs from the safe list
- View all currently trusted programs

### Scan Settings
- Configure scan depth and intensity
- Set file size limits for scanning
- Configure heuristic analysis settings

### Quarantine Management
- View all quarantined files with details
- Restore files from quarantine
- Delete files from quarantine
- Clear all quarantined files

### Advanced Features

#### Scheduled Scans
- Enable/disable scheduled scans
- Set scan frequency (daily, weekly, monthly)
- Configure scan time and type

#### Network Protection
- Enable/disable network protection
- Configure firewall settings
- Block suspicious network connections

#### Real-time Protection
- Enable/disable real-time protection
- Configure scanning of new files
- Set up behavioral analysis

#### Privacy Protection
- Block webcam access
- Block microphone access
- Prevent keyloggers

#### Web Protection
- Block malicious websites
- Block phishing attempts
- Prevent tracking

#### System Optimization
- Clean temporary files
- Defragment disk
- Optimize startup

#### Reports
- Generate weekly reports
- Email reports to specified address
- Configure report types (scan, threat, system)

#### Update Management
- Configure automatic updates
- Set update frequency
- Select components to update (virus definitions, scanning engine, application)

#### Exclusions
- Add files and folders to exclusion list
- Add file extensions to exclusion list
- Manage and save exclusions

#### Backup & Restore
- Configure automatic backups
- Set backup frequency and location
- Select items to backup (settings, safe programs, quarantine, logs)
- Perform manual backups
- Restore from previous backups

## Security Features

SpeedSFV includes several security features:

## Disclaimer

This is a prototype application for educational purposes. A production-ready antivirus solution would require extensive security testing, continuous updates, and additional features.

## License

MIT
