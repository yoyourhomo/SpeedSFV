import os
import psutil
import platform
import datetime

def get_file_size_str(size_in_bytes):
    """Convert file size in bytes to human-readable format"""
    for unit in ['B', 'KB', 'MB', 'GB', 'TB']:
        if size_in_bytes < 1024.0:
            return f"{size_in_bytes:.2f} {unit}"
        size_in_bytes /= 1024.0
    return f"{size_in_bytes:.2f} PB"

def get_system_info():
    """Get basic system information"""
    info = {}
    
    # CPU info
    info['cpu_percent'] = psutil.cpu_percent(interval=0.1)
    info['cpu_count'] = psutil.cpu_count(logical=True)
    
    # Memory info
    memory = psutil.virtual_memory()
    info['memory_total'] = get_file_size_str(memory.total)
    info['memory_available'] = get_file_size_str(memory.available)
    info['memory_percent'] = memory.percent
    
    # Disk info
    disk = psutil.disk_usage('/')
    info['disk_total'] = get_file_size_str(disk.total)
    info['disk_free'] = get_file_size_str(disk.free)
    info['disk_percent'] = disk.percent
    
    # OS info
    info['os'] = platform.system()
    info['os_version'] = platform.version()
    info['hostname'] = platform.node()
    
    # Time info
    info['current_time'] = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    
    return info

def is_admin():
    """Check if the application is running with admin privileges"""
    try:
        import ctypes
        return ctypes.windll.shell32.IsUserAnAdmin() != 0
    except:
        return False

def get_startup_items():
    """Get a list of programs that start automatically with Windows"""
    startup_items = []
    
    # This is a simplified version - a real implementation would check registry and other locations
    startup_dirs = [
        os.path.join(os.environ["APPDATA"], "Microsoft", "Windows", "Start Menu", "Programs", "Startup"),
        os.path.join(os.environ["PROGRAMDATA"], "Microsoft", "Windows", "Start Menu", "Programs", "Startup")
    ]
    
    for startup_dir in startup_dirs:
        if os.path.exists(startup_dir):
            for item in os.listdir(startup_dir):
                item_path = os.path.join(startup_dir, item)
                startup_items.append({
                    'name': item,
                    'path': item_path,
                    'type': 'Startup folder'
                })
    
    return startup_items
