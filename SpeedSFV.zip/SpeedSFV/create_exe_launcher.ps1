# PowerShell script to create a simple EXE launcher for SpeedSFV

# Create a C# code for a simple launcher
$sourceCode = @"
using System;
using System.Diagnostics;
using System.IO;
using System.Windows.Forms;

namespace SpeedSFVLauncher
{
    class Program
    {
        [STAThread]
        static void Main()
        {
            try
            {
                string appPath = Path.GetDirectoryName(Application.ExecutablePath);
                string batchFile = Path.Combine(appPath, "Launch_SpeedSFV.bat");
                
                if (!File.Exists(batchFile))
                {
                    MessageBox.Show("Could not find Launch_SpeedSFV.bat in the application directory.", 
                        "SpeedSFV Launcher Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return;
                }
                
                ProcessStartInfo startInfo = new ProcessStartInfo();
                startInfo.FileName = "cmd.exe";
                startInfo.Arguments = "/c " + batchFile;
                startInfo.WorkingDirectory = appPath;
                startInfo.CreateNoWindow = true;
                startInfo.UseShellExecute = false;
                
                Process.Start(startInfo);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error launching SpeedSFV: " + ex.Message, 
                    "SpeedSFV Launcher Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
    }
}
"@

# Save the C# code to a temporary file
$codeFile = [System.IO.Path]::GetTempFileName() + ".cs"
$sourceCode | Out-File -FilePath $codeFile -Encoding UTF8

# Compile the C# code to an executable
$outputFile = "SpeedSFV_Launcher.exe"

Write-Host "Creating SpeedSFV launcher executable..."

try {
    # Use the C# compiler to create the executable
    $csc = "C:\Windows\Microsoft.NET\Framework\v4.0.30319\csc.exe"
    if (Test-Path $csc) {
        $compilerParams = @(
            "/target:winexe",
            "/out:$outputFile",
            "/reference:System.Windows.Forms.dll",
            $codeFile
        )
        
        # Execute the compiler with parameters
        & $csc $compilerParams
        
        if (Test-Path $outputFile) {
            Write-Host "Successfully created $outputFile"
            Write-Host "You can now launch SpeedSFV by double-clicking this executable."
        } else {
            Write-Host "Failed to create the launcher executable."
        }
    } else {
        # Alternative method using Add-Type
        Add-Type -OutputAssembly $outputFile -OutputType WindowsApplication -ReferencedAssemblies "System.Windows.Forms" -TypeDefinition $sourceCode
        
        if (Test-Path $outputFile) {
            Write-Host "Successfully created $outputFile"
            Write-Host "You can now launch SpeedSFV by double-clicking this executable."
        } else {
            Write-Host "Failed to create the launcher executable."
        }
    }
} catch {
    Write-Host "Error creating executable: $_"
}

# Clean up the temporary file
if (Test-Path $codeFile) {
    Remove-Item $codeFile
}
