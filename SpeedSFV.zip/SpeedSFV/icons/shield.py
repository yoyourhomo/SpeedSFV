from PIL import Image, ImageDraw
import os

def create_shield_icon():
    """Create a simple shield icon for the antivirus application"""
    # Create a new image with a transparent background
    img = Image.new('RGBA', (512, 512), color=(0, 0, 0, 0))
    draw = ImageDraw.Draw(img)
    
    # Draw a shield shape
    shield_color = (30, 120, 200)  # Blue
    outline_color = (20, 80, 140)  # Darker blue
    
    # Shield outline
    points = [
        (256, 50),  # Top
        (450, 120),  # Top right
        (400, 400),  # Bottom right
        (256, 462),  # Bottom
        (112, 400),  # Bottom left
        (62, 120)    # Top left
    ]
    draw.polygon(points, fill=shield_color, outline=outline_color)
    
    # Draw a checkmark
    check_color = (255, 255, 255)  # White
    check_points = [
        (150, 256),  # Start
        (220, 326),  # Middle
        (362, 184)   # End
    ]
    draw.line(check_points, fill=check_color, width=30)
    
    # Save the image
    img.save('shield.png')
    print("Shield icon created successfully.")

if __name__ == "__main__":
    create_shield_icon()
