import os
import random
import hashlib
import time

class Scanner:
    def __init__(self):
        # In a real antivirus, this would load virus signatures
        self.known_malicious_hashes = [
            "e1112134b6dcc8bed54e0e34d8ac272795e73d74",
            "3395856ce81f2b7382dee72602f798b642f14140",
            "5c1e20f493149e3af9c4d1b1f0e95447d24bec9b",
            "275a021bbfb6489e54d471899f7db9d1663fc695",
            "aaf4c61ddcc5e8a2dabede0f3b482cd9aea9434d"
        ]
        
        # Common malicious file extensions
        self.suspicious_extensions = [
            ".exe", ".dll", ".bat", ".cmd", ".ps1", ".vbs", ".js", 
            ".jar", ".scr", ".pif", ".hta", ".com"
        ]
        
        # Simulated malware patterns
        self.malware_patterns = [
            b"X5O!P%@AP[4\\PZX54(P^)7CC)7}$EICAR",  # EICAR test string
            b"CreateRemoteThread",
            b"VirtualAlloc",
            b"ShellExecute",
            b"WScript.Shell",
            b"HKEY_LOCAL_MACHINE\\Software\\Microsoft\\Windows\\CurrentVersion\\Run",
            b"netsh firewall add",
            b"taskkill /f",
            b"reg delete",
            b"attrib +h +s +r"
        ]
    
    def scan_file(self, file_path):
        """
        Scan a file for potential threats.
        In a real antivirus, this would use more sophisticated techniques.
        
        Returns True if the file is suspicious and needs further analysis.
        """
        try:
            # Skip very large files for this demo
            if os.path.getsize(file_path) > 100 * 1024 * 1024:  # 100 MB
                return False
            
            # Check if the file extension is suspicious
            _, ext = os.path.splitext(file_path.lower())
            is_executable = ext in self.suspicious_extensions
            
            # For demo purposes, we'll randomly flag some executable files
            # In a real antivirus, this would use actual detection methods
            if is_executable and random.random() < 0.005:  # Reduced to 0.5% chance for faster scanning
                return True
            
            # For small files, check content for known patterns
            if os.path.getsize(file_path) < 1 * 1024 * 1024:  # Reduced to 1 MB for faster scanning
                try:
                    with open(file_path, "rb") as f:
                        content = f.read(1024)  # Reduced to first 1KB for faster scanning
                        
                        # Check for known malware patterns
                        for pattern in self.malware_patterns:
                            if pattern in content:
                                return True
                        
                        # Check file hash against known malicious hashes
                        file_hash = hashlib.sha1(content).hexdigest()
                        if file_hash in self.known_malicious_hashes:
                            return True
                except (PermissionError, OSError):
                    # Can't read the file, skip it
                    pass
            
            return False
        except Exception as e:
            print(f"Error scanning {file_path}: {e}")
            return False
